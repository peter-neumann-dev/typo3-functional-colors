-- MariaDB dump 10.19  Distrib 10.11.6-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	10.11.7-MariaDB-1:10.11.7+maria~ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` text NOT NULL,
  `icon` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(120) NOT NULL DEFAULT '',
  `title` varchar(120) NOT NULL DEFAULT '',
  `widgets` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `identifier` (`identifier`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES
(1,0,1669973002,1669973002,2,0,0,0,0,'c0bdf22023622de49659bda0ca069b15074b87cb','My dashboard',NULL),
(2,0,1715029669,1715029669,1,0,0,0,0,'ae86997b21010cd2b376103db01002b04f9ba885','My dashboard','{\"5964ff0198c23de77bb3a90e8be5e5fa2289efde\":{\"identifier\":\"t3information\"},\"887efc08aa87a478a8636144942e03852e59521a\":{\"identifier\":\"docGettingStarted\"}}');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `non_exclude_fields` text DEFAULT NULL,
  `explicit_allowdeny` text DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` text DEFAULT NULL,
  `db_mountpoints` text DEFAULT NULL,
  `pagetypes_select` text DEFAULT NULL,
  `tables_select` text DEFAULT NULL,
  `tables_modify` text DEFAULT NULL,
  `groupMods` text DEFAULT NULL,
  `availableWidgets` text DEFAULT NULL,
  `mfa_providers` text DEFAULT NULL,
  `file_mountpoints` text DEFAULT NULL,
  `file_permissions` text DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `subgroup` text DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_adminpanel_requestcache`
--

DROP TABLE IF EXISTS `cache_adminpanel_requestcache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_adminpanel_requestcache` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_adminpanel_requestcache`
--

LOCK TABLES `cache_adminpanel_requestcache` WRITE;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_adminpanel_requestcache_tags`
--

DROP TABLE IF EXISTS `cache_adminpanel_requestcache_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_adminpanel_requestcache_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_adminpanel_requestcache_tags`
--

LOCK TABLES `cache_adminpanel_requestcache_tags` WRITE;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_adminpanel_requestcache_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes`
--

DROP TABLE IF EXISTS `cache_imagesizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes`
--

LOCK TABLES `cache_imagesizes` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes_tags`
--

DROP TABLE IF EXISTS `cache_imagesizes_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes_tags`
--

LOCK TABLES `cache_imagesizes_tags` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES
(1,'redirects_4fa4c4c69d490d474f429f6ca04ab1d5c68f1ce2',1715099146,'x�K�2���\0O�'),
(2,'redirects_df58248c414f342c81e056b40bee12d17a08bf61',1715099146,'x�K�2���\0O�');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(1,'1__0_0_1_1',1717687540,'x�M��N\�0D�\�iZ�\�^�G�\��m\�\�N�\�x#{]�P��M\"��y^\�3������r�Urŧ(\�RV�\�\�&�fU�z��\�\'\0o\�2ßX\�:\�H�LƏL-9\�Q>H\��td_�Np�Ėb��@OR8u\�Dّ��\�\��؋#����)�\�%y��3p��½f7\�K<\�\�.\�u0�\�\�x�\�`r\�\�\�Z\��=��7��j�\�-޿\Zɳ��.��,z\�E�!VoӕԈ�&κ�\�j���8�.��88��uI�K\�v\�m�h\�D*��\�\�	�ǬWt���\�j��\�0��k\0gN\�M<0nF@�N%\�9�\�?ιa'),
(2,'1__0_0_0_0',1717687546,'x�M��N\�0D�\�iZ�\�^�G�\��m\�\�N�\�x#{]�P��M\"��y^\�3������r�Urŧ(\�RV�\�\�&�fU�z��\�\'\0o\�2ßX\�:\�H�LƏL-9\�Q>H\��td_�Np�Ėb��@OR8u\�Dّ��\�\��؋#����)�\�%y��3p��½f7\�K<\�\�.\�u0�\�\�x�\�`r\�\�\�Z\��=��7��j�\�-޿\Zɳ��.��,z\�E�!VoӕԈ�&κ�\�j���8�.��88��uI�K\�v\�m�h\�D*��\�\�	�ǬWt���\�j��\�0��k\0gN\�M<0nF@�N%\�9�\�?ιa'),
(3,'16__0_0_0_0',1717687546,'x�ݒ1O1��\n\�\�׻B�t!$��ځ-J/�5��PU�\��z���N��\���e[\�o\r/��W%\�>\�3�M{��\�W5�\�3��0��r�\�{\�h�h@�:\�K�-\�$�\�\��5\�ٓYx\�7l�pr-*rgCc����pf\�\"&soF)\� /J\���=Lpřv*\'ל5Z,=\�.s/\�M i\�0��N.u\�<�p\�\�\'\�\�jp�Y�\�s\�N\Z\�\�6���۞\�c���l\��C\�e��2(�&^\�N�^шbX�p4��z�\�!j׋w\�\�Ǿ-�\�Z�OJJ�5mON^眴0Mt5\ZpҊ\Z,�P\�\�[��=.\�a��J+�\�\�\��\�o_R�KJ\��aB\�FFK9�\�\'~mO�'),
(4,'47__0_0_0_0',1717687546,'x�͒?O\�0ſJ\��\�B�]�S�\�l��8��\�\�s���ݹ$u	��\��d\�O\�\�\�N\�4O���	?8>\�\�[v���P\�T>p���j0&�\�~�Mu(Q|KT���$d�nd�m51P\�\r�܉��\�\�\�V��#tǙ�{\��	�\�P6\0\�\�-��\��)[�\�=g�U�\�Sq\�/٩O$qk�id�\�Ȥ�-\�\�D&\�:[\�-W\�wҠ�\�67�\���N�\�N8���Q\�\Z�Eь����\0xJ\�\�\�|K\�\�0a)�0j�\�yF\�N|�\��\�^�k�u\�\�\�\�_,\�\���]��:?꺁\'\�緌�f�\�6G\rV\Z���\�EO�\�\�G�\�蕺E]˛pS\���|g���\�\�W���K�N�B�\�\�s<~\�=NV'),
(5,'46__0_0_0_0',1717687546,'x�͒?O\�0ſJ\�$NKwABHL�\�,;��cG�S��~w\�\r.F炙\��\�\�HEv�\�9#&;G&\���yd�*\�t\�-A~�����p�\�\�(N\�y\�E\�W@�WP;R\�\��/\\m�R��q�\�\�+�׭5As�C\�6\�8^h�\��,C3�ۚ\�St\0o�s��7hA\�\�y�	�\�B5�\�}��AM|x\�]�ex\�Y+\\��\�\�o{��Ac���nd�\�8=\�\r�J]��\��\�kQ\�Q\'��\��,l[\�\�vZe�\Z�x\�{�tt\�\��*�\���}l>�r�\�\��\�G�\�h:\�[��\�\�\0\�w�\�\��\�\�ˊ@��\�&\�\�K����Qƺ\��0,��X��.������\�?�\�\�\�;\�\�/�\��%\Zb2\�(\�aA�\�~�	\�\�S\�');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(1,'1__0_0_1_1','pageId_1'),
(2,'1__0_0_0_0','pageId_1'),
(3,'16__0_0_0_0','pageId_16'),
(4,'16__0_0_0_0','pageId_1'),
(5,'47__0_0_0_0','pageId_47'),
(6,'47__0_0_0_0','pageId_1'),
(7,'46__0_0_0_0','pageId_46'),
(8,'46__0_0_0_0','pageId_1');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_treelist`
--

DROP TABLE IF EXISTS `cache_treelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_treelist` (
  `md5hash` varchar(32) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT 0,
  `treelist` mediumtext DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`md5hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_treelist`
--

LOCK TABLES `cache_treelist` WRITE;
/*!40000 ALTER TABLE `cache_treelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_treelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` tinytext DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` text DEFAULT NULL,
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` tinytext DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `lastlogin` int(11) NOT NULL DEFAULT 0,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` varchar(2048) DEFAULT NULL,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text DEFAULT NULL,
  `is_siteroot` smallint(6) NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(6) NOT NULL DEFAULT 0,
  `url` varchar(255) NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` int(11) NOT NULL DEFAULT 0,
  `keywords` text DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `newUntil` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` text DEFAULT NULL,
  `module` varchar(255) NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(6) NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `l18n_cfg` smallint(6) NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1715028304,1669973002,0,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'{\"title\":\"\"}',0,0,0,0,0,1,31,31,0,'Home','/',1,'@import \'EXT:typo3_functional_colors/Configuration/TsConfig/Page/page.tsconfig\'',1,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1715028304,NULL,'',0,'','','',0,0,0,0,0,'pagets__default','pagets__default','',0),
(16,1,1715070261,1669973002,0,0,0,0,'',24,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,0,1,31,31,0,'Atomic-Library','/atomic-library',1,NULL,0,0,'/typo3conf/ext/buffpackage/Resources/Public/atomic-library.html',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1715070261,NULL,'',0,'','','',0,0,0,0,0,'','','',0),
(46,1,1715074149,1715070245,0,0,0,0,'',48,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"description\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'On-scroll fading backgrounds','/on-scroll-fading-backgrounds',1,NULL,0,0,'',0,0,'',1,'',0,0,NULL,0,'',0,NULL,0,1715074149,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0),
(47,1,1715072686,1715072678,0,0,0,0,'0',36,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Spacing logic','/spacing-logic',1,NULL,0,0,'',0,0,'',0,'',0,0,NULL,0,'',0,NULL,0,1715072686,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext NOT NULL,
  `items` int(11) NOT NULL DEFAULT 0,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(6) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `type` varchar(10) NOT NULL DEFAULT '',
  `metadata` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1705959217,1705959217,0,1,'2',0,'/sample_data/aboodi-vesakaran-e5eq9Mi0UEs-unsplash.jpg','d7891028e4b95f3ad1ebfd315e6baf0899fd278e','3b538e039cddf8a176e8e29599eac1cf1735d941','jpg','image/jpeg','aboodi-vesakaran-e5eq9Mi0UEs-unsplash.jpg','2d6c6b8bc35bcc52834d7beeb4926cd29881aedd',773637,1705959217,1705959216),
(2,0,1705959263,1705959263,0,1,'2',0,'/sample_data/uran-wang-ao2K-lkq8cI-unsplash.jpg','ae4c2f150506ee25dffae45939e80f15d68044d8','3b538e039cddf8a176e8e29599eac1cf1735d941','jpg','image/jpeg','uran-wang-ao2K-lkq8cI-unsplash.jpg','6a03607d114077ec44d1b120dcf7a1faf1a0e979',236842,1705959263,1705959263),
(3,0,1705959286,1705959286,0,1,'2',0,'/sample_data/andrew-ridley-Kt5hRENuotI-unsplash.jpg','5abb3faecdc4417ae87a9ce2c918ef1254ac5593','3b538e039cddf8a176e8e29599eac1cf1735d941','jpg','image/jpeg','andrew-ridley-Kt5hRENuotI-unsplash.jpg','5bd87e470c6130526c30d06faa6f7cd2edf80330',781127,1705959286,1705959286),
(4,0,1705959309,1705959309,0,1,'2',0,'/sample_data/ryan-geller-TRquyIT7OLQ-unsplash.jpg','20319f10d33bd2a286f9e430ef2b94ed26cadcf7','3b538e039cddf8a176e8e29599eac1cf1735d941','jpg','image/jpeg','ryan-geller-TRquyIT7OLQ-unsplash.jpg','70ff4687b1b6cc3088640e667109ae95267867cb',1884423,1705959309,1705959309),
(5,0,1705959649,1705959649,0,1,'2',0,'/sample_data/verne-ho-0LAJfSNa-xQ-unsplash.jpg','d08b1d36e48bacfa8b3ba0e9743764b6be18e042','3b538e039cddf8a176e8e29599eac1cf1735d941','jpg','image/jpeg','verne-ho-0LAJfSNa-xQ-unsplash.jpg','80b5b9c1a59a4fa3f541b72f940de6890aca354b',366935,1705959649,1705959649),
(6,0,1705959320,1705959320,0,1,'2',0,'/sample_data/chris-lawton-6tfO1M8_gas-unsplash.jpg','113eb4ca13901fa7d782f446d06e06e770b4f4a9','3b538e039cddf8a176e8e29599eac1cf1735d941','jpg','image/jpeg','chris-lawton-6tfO1M8_gas-unsplash.jpg','7f1ec56019352cb403f438212869d7ef2fa2a9eb',583707,1705959320,1705959320),
(8,0,1669973006,0,0,1,'1',0,'/form_definitions/example.form.yaml','19de2c51100a2b6d167757cef8d9f459ef26ad55','c62e3e70a526a59f0f0b7687864947eab72d7d3f','yaml','text/plain','example.form.yaml','6f78964671e553b6ea197126769cd11c814287c5',5550,1669973006,1669973006),
(9,0,1669973006,0,0,1,'1',0,'/form_definitions/kontaktformular.form.yaml','33ae0774ae03e6a275be2d1036b636318c3e125a','c62e3e70a526a59f0f0b7687864947eab72d7d3f','yaml','text/plain','kontaktformular.form.yaml','1e9b098022a21b25b9e8ed24f752cafe176af6fd',2269,1669973006,1669973006),
(10,0,1683489978,0,0,1,'2',0,'/sample_data/logoipsum-1.svg','cf64d1c18e7afcbc4402e0504bab6bc7f1dec294','3b538e039cddf8a176e8e29599eac1cf1735d941','svg','image/svg+xml','logoipsum-1.svg','9c75f66cdc102803fa39adefc714412ed8fdaa7d',5060,1683489455,1683489455),
(11,0,1683489978,0,0,1,'2',0,'/sample_data/logoipsum-2.svg','f98ffab066993407b3add4f52b86fc27d6483c64','3b538e039cddf8a176e8e29599eac1cf1735d941','svg','image/svg+xml','logoipsum-2.svg','67207ac1919e0e46ea99a0ec87e4f11a0261a113',3351,1683489455,1683489455),
(12,0,1683489978,0,0,1,'2',0,'/sample_data/logoipsum-3.svg','5cb24f0143ea9ac79c7895e767a16e11584b892c','3b538e039cddf8a176e8e29599eac1cf1735d941','svg','image/svg+xml','logoipsum-3.svg','360c7d35448656c14a01bf546b29e18d6a7a6488',8638,1683489455,1683489455),
(13,0,1683489978,0,0,1,'2',0,'/sample_data/logoipsum-4.svg','808f95847120b2796ceecda4f4afe17d29bcfd43','3b538e039cddf8a176e8e29599eac1cf1735d941','svg','image/svg+xml','logoipsum-4.svg','2095fcfafb067d6290633dd4ffa931ed263561fc',5485,1683489455,1683489455),
(14,0,1683489978,0,0,1,'2',0,'/sample_data/logoipsum-5.svg','636df9bee226be208f3c67f8e90857678487c403','3b538e039cddf8a176e8e29599eac1cf1735d941','svg','image/svg+xml','logoipsum-5.svg','a0d2d9bb87081abcfe575a32326ab3bfcaaab2cf',6463,1683489455,1683489455),
(15,0,1683489978,0,0,1,'4',0,'/sample_data/street.mp4','d92b574bea93e36806c17cd87641d4bad902f947','3b538e039cddf8a176e8e29599eac1cf1735d941','mp4','video/mp4','street.mp4','2891e8e0953cb5e254868f28a1504a320b345c67',10827423,1683489456,1683489456),
(17,0,1705959231,1705959231,0,1,'2',0,'/sample_data/gerrit-vermeulen-l42IbsOdTk8-unsplash.jpg','86911190d3be8ad1bfeb04debb13e392ffabfe35','3b538e039cddf8a176e8e29599eac1cf1735d941','jpg','image/jpeg','gerrit-vermeulen-l42IbsOdTk8-unsplash.jpg','af33c1e9460f73337d8188880f5d01241d44dd0c',44853,1705959231,1705959231),
(18,0,1705959247,1705959247,0,1,'2',0,'/sample_data/neom-THlO6Mkf5uI-unsplash.jpg','a4e01a860df2214bdbfe24583a16e33049d1259a','3b538e039cddf8a176e8e29599eac1cf1735d941','jpg','image/jpeg','neom-THlO6Mkf5uI-unsplash.jpg','f4eeb55c9ae8c8269a0c008651cb5427e4e2cd7a',551213,1705959247,1705959247),
(19,0,1669974516,0,0,0,'1',0,'/typo3conf/ext/buffpackage/Resources/Public/atomic-library.html','17a433076699df1c859b7b18117a7990a968646c','af91229b5fc7378b9adf3e419ece1eb0d2e5662a','html','text/html','atomic-library.html','94f5cd9e75cd950ca30edbbbbfcd3f9981811b4d',20149,1669973628,1669973611),
(20,0,1669974517,0,0,0,'2',0,'/typo3conf/ext/buffpackage/Resources/Public/Images/logo.svg','9eba152a68f59c5d5768d3f28cb08f26e01d5dc7','115159d74fa1394c279a810ae000781c3770a19b','svg','image/svg+xml','logo.svg','5697f304843690165bc13d6f934239f77b09fcd6',24166,1669973628,1669973611),
(21,0,1669974555,0,0,0,'2',0,'/typo3conf/ext/buffpackage/Resources/Public/Images/map-wall.jpg','963e35fd9dfd6a55f2fa9c65aab2bb7e4e777f25','115159d74fa1394c279a810ae000781c3770a19b','jpg','image/jpeg','map-wall.jpg','7ea49a48fc3ea8b57bd89a87fe5549b31ffac7e0',499095,1669973628,1669973611),
(22,0,1683399033,0,0,0,'2',0,'/typo3conf/ext/mask/Resources/Public/Icons/Extension.svg','857a9f6a260d54c788401bc0e7d65aecce1a335b','2876cf204caa6654736d53a410b6bcf23ad17794','svg','image/svg+xml','Extension.svg','a247c773642ec1903e8cf7eb404741bdfff03e56',1294,1683397190,1683030674),
(23,0,1683399033,0,0,0,'2',0,'/typo3conf/ext/mask/Resources/Public/Images/legacy-icon.gif','888cfacbfd3dc904996311359a273fe4064d9fea','150956d7ec32e8e20d0ec30ce3676a4eb464ffb8','gif','image/gif','legacy-icon.gif','921d78071223f0a62a53abf559e1810654083295',366,1683397190,1683030674),
(24,0,1683399033,0,0,0,'2',0,'/typo3conf/ext/mask/Resources/Public/Images/Logo_TVconverter.png','29ccf17beb214a178e3c37f6b47cb6403ac20385','150956d7ec32e8e20d0ec30ce3676a4eb464ffb8','png','image/png','Logo_TVconverter.png','dfeb3eea11a491fc84b468c8a5198914bd8fb08d',5657,1683397190,1683030674),
(25,0,1683399033,0,0,0,'2',0,'/typo3conf/ext/mask/Resources/Public/Icons/MaskUkraine.svg','5cb9faa14233796b19810085c0e84e65266a591d','2876cf204caa6654736d53a410b6bcf23ad17794','svg','image/svg+xml','MaskUkraine.svg','707debba0c50806983a78a1be9487dd6e9af5c77',2031,1683397190,1683030674),
(26,0,1705959274,1705959274,0,1,'2',0,'/sample_data/alexander-abero-OypnYfdiQgg-unsplash.jpg','945e12b810ea6386f9e70827d83ccdc06c2c4aaf','3b538e039cddf8a176e8e29599eac1cf1735d941','jpg','image/jpeg','alexander-abero-OypnYfdiQgg-unsplash.jpg','6bd531f6c089e07d9d000199e442c82b3034cc9a',813095,1705959274,1705959274),
(27,0,1697360992,0,0,0,'2',0,'/_assets/dca94d8cd3b58fdfd24fde44814e41a3/Images/logo.svg','4c0f8adb884012f8dd3809b4793b82de66b19a2b','533f417be87d00e8801d7a09b5d024374f3e186b','svg','image/svg+xml','logo.svg','5697f304843690165bc13d6f934239f77b09fcd6',24166,1697360788,1697360788),
(28,0,1697361028,0,0,0,'2',0,'/_assets/dca94d8cd3b58fdfd24fde44814e41a3/Images/map-wall.jpg','705b192b4efe904591252dfb48a4673402557f55','533f417be87d00e8801d7a09b5d024374f3e186b','jpg','image/jpeg','map-wall.jpg','7ea49a48fc3ea8b57bd89a87fe5549b31ffac7e0',499095,1697360788,1697360788),
(29,0,1705787631,1705787631,0,0,'2',0,'/_assets/a19a52d18aa5fcd2da308163624eb166/Icons/Extension.svg','5b1dc350606c0e9f45e1fe76012a7a72acbee4eb','5aa5b076edbbac548b38f4d22f6066096c8aed83','svg','image/svg+xml','Extension.svg','a247c773642ec1903e8cf7eb404741bdfff03e56',1294,1705786642,1705592155),
(30,0,1705787631,1705787631,0,0,'2',0,'/_assets/a19a52d18aa5fcd2da308163624eb166/Images/legacy-icon.gif','81905e53291c255353f8dfcd0b14aa0e50c1552f','25a674f6a5e8a849080966e9f63e83efa7555263','gif','image/gif','legacy-icon.gif','921d78071223f0a62a53abf559e1810654083295',366,1705786642,1705592155),
(31,0,1705787631,1705787631,0,0,'2',0,'/_assets/a19a52d18aa5fcd2da308163624eb166/Images/Logo_TVconverter.png','dc4d971a7aa8f41fc058b67fdeee7f5e0580d78b','25a674f6a5e8a849080966e9f63e83efa7555263','png','image/png','Logo_TVconverter.png','dfeb3eea11a491fc84b468c8a5198914bd8fb08d',5657,1705786642,1705592155),
(32,0,1705787631,1705787631,0,0,'2',0,'/_assets/a19a52d18aa5fcd2da308163624eb166/Icons/MaskUkraine.svg','315ee25e92e2ed53388caf0e9bca111de57aec62','5aa5b076edbbac548b38f4d22f6066096c8aed83','svg','image/svg+xml','MaskUkraine.svg','707debba0c50806983a78a1be9487dd6e9af5c77',2031,1705786642,1705592155),
(33,0,1705959341,1705959341,0,1,'2',0,'/sample_data/luca-bravo-ESkw2ayO2As-unsplash.jpg','54abf9f970b64e150f9b5f11ff6dc25567d5e095','3b538e039cddf8a176e8e29599eac1cf1735d941','jpg','image/jpeg','luca-bravo-ESkw2ayO2As-unsplash.jpg','4652862fad0730bfc374179e36e04148d9407842',1204451,1705959341,1705959341),
(34,0,1705959864,1705959864,0,1,'5',0,'/user_upload/index.html','c25533f303185517ca3e1e24b215d53aa74076d2','19669f1e02c2f16705ec7587044c66443be70725','html','application/x-empty','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',0,1705671157,1700603623),
(35,0,1705960357,1705960357,0,1,'4',0,'/sample_data/Vimeo___Video_Power.vimeo','693d4aec0707dc362dacfac1965473cfa8853189','3b538e039cddf8a176e8e29599eac1cf1735d941','vimeo','video/vimeo','Vimeo___Video_Power.vimeo','4b60e1805c03426c01c264aa5fecc1a452d93a46',9,1705960357,1705959986),
(37,0,1705960345,1705960345,0,1,'4',0,'/sample_data/Introducing_Apple_Vision_Pro.youtube','bcb2d14a2f7e416f67f8b535d15b3515f0a1a01c','3b538e039cddf8a176e8e29599eac1cf1735d941','youtube','video/youtube','Introducing_Apple_Vision_Pro.youtube','82e9a159ec7e3e87b46f03e1985d0cfa58c58540',11,1705960345,1705960345),
(38,0,1705960847,1705960847,0,1,'2',0,'/sample_data/pouya-hajiebrahimi-7To9qeHc9oM-unsplash.jpg','c57b556cbd35630491ab1b06ab723d2b9fea54f0','3b538e039cddf8a176e8e29599eac1cf1735d941','jpg','image/jpeg','pouya-hajiebrahimi-7To9qeHc9oM-unsplash.jpg','24872be8828cf99e714463c43ffcf82b9ba7285c',236251,1705960847,1705960847),
(39,0,1705960847,1705960847,0,1,'2',0,'/sample_data/thom-holmes-Wq9Iw5EhOf0-unsplash.jpg','4bfd738b164dc3f8214e0a62317d7196d7b35de7','3b538e039cddf8a176e8e29599eac1cf1735d941','jpg','image/jpeg','thom-holmes-Wq9Iw5EhOf0-unsplash.jpg','501e3823fedb332e5ad1c3893a6939780859bb97',307874,1705960847,1705960847),
(40,0,1705960847,1705960847,0,1,'2',0,'/sample_data/rinke-dohmen-gsRQTJ78wGU-unsplash.jpg','4cbdac2548c5a21acce723e54b9eb5532ca2295d','3b538e039cddf8a176e8e29599eac1cf1735d941','jpg','image/jpeg','rinke-dohmen-gsRQTJ78wGU-unsplash.jpg','1c5c14d57b10590c3951e74e700b95adcb97e00f',248899,1705960847,1705960847),
(41,0,1705960899,1705960899,0,1,'2',0,'/sample_data/jeffrey-keenan-pUhxoSapPFA-unsplash.jpg','3639df618a8aeb13cc635251c27e151e1ad72f98','3b538e039cddf8a176e8e29599eac1cf1735d941','jpg','image/jpeg','jeffrey-keenan-pUhxoSapPFA-unsplash.jpg','0b0c7eb2e0ef2cb264e9c7ec690891310e6a94b7',451160,1705960899,1705960899),
(42,0,1705960982,1705960982,0,1,'2',0,'/sample_data/irene-strong-TMt3JGoVlng-unsplash.jpg','ba6de876fe6501201a4059f7f6f8ae9e7bb1ba6f','3b538e039cddf8a176e8e29599eac1cf1735d941','jpg','image/jpeg','irene-strong-TMt3JGoVlng-unsplash.jpg','c2a63e33d8130300005cde4f484d2098faa50c48',363357,1705960982,1705960982),
(43,0,1705961588,1705961588,0,1,'2',0,'/sample_data/sayo-garcia-NkOGfv7d5rY-unsplash.jpg','ef76a6babc485d620a93c1fdd068e8071ad7efa1','3b538e039cddf8a176e8e29599eac1cf1735d941','jpg','image/jpeg','sayo-garcia-NkOGfv7d5rY-unsplash.jpg','85b763256bb37ef142007069dc9e5158fc3814fb',356027,1705961588,1705961588),
(44,0,1705962051,1705962051,0,1,'2',0,'/sample_data/christopher-campbell-rDEOVtE7vOs-unsplash.jpg','21d184ec435bf170d283165cbca470531f563e8b','3b538e039cddf8a176e8e29599eac1cf1735d941','jpg','image/jpeg','christopher-campbell-rDEOVtE7vOs-unsplash.jpg','7f341592deffdb3f13ed2b13e8225250f151942a',276561,1705962051,1705962051),
(45,0,1708625194,1708625194,0,0,'2',0,'/_assets/19b814ad90c7db12d898e4f4aedb0ee5/Icons/Backend/Mask/text.svg','c7838473647bd1ccfaf17c21ff05ffabf96e7c86','8aeb4ebef8411bab466c7e17b07de8a6aaea2a94','svg','image/svg+xml','text.svg','b8ac4d9b669c6260b3e46f3f8845b13257d84ec7',331,1708625067,1708625066),
(46,0,1708625312,1708625312,0,0,'2',0,'/_assets/19b814ad90c7db12d898e4f4aedb0ee5/Icons/Backend/Mask/image_beside_text.svg','051129c45f1800af70ab7fee1780715145faa869','8aeb4ebef8411bab466c7e17b07de8a6aaea2a94','svg','image/svg+xml','image_beside_text.svg','b0c50facaeba2d4fda87ddf6541b8d87af140903',272,1708625067,1708625066),
(47,0,1708625312,1708625312,0,0,'2',0,'/_assets/19b814ad90c7db12d898e4f4aedb0ee5/Icons/Backend/Mask/image.svg','bad11be73ee46594922d9838ced98a4c685aa1c0','8aeb4ebef8411bab466c7e17b07de8a6aaea2a94','svg','image/svg+xml','image.svg','6dd850715242b82bbc359b1f59da83e1facd2a34',308,1708625067,1708625066),
(48,0,1708625312,1708625312,0,0,'2',0,'/_assets/19b814ad90c7db12d898e4f4aedb0ee5/Icons/Backend/Mask/gallery.svg','882b8f5355a410b50cec267befb08b938e6b31bc','8aeb4ebef8411bab466c7e17b07de8a6aaea2a94','svg','image/svg+xml','gallery.svg','b95c538ecb1d0cc470b53ade6ceb96acfac70434',481,1708625067,1708625066),
(49,0,1708625312,1708625312,0,0,'2',0,'/_assets/19b814ad90c7db12d898e4f4aedb0ee5/Icons/Backend/Mask/video.svg','d63da71bd49afa2954139a3ccb038bffdaa13f55','8aeb4ebef8411bab466c7e17b07de8a6aaea2a94','svg','image/svg+xml','video.svg','4bec0a35a06e6a026239fd69488570e406d88be3',420,1708625067,1708625066),
(50,0,1708625312,1708625312,0,0,'2',0,'/_assets/19b814ad90c7db12d898e4f4aedb0ee5/Icons/Backend/Mask/teaserbox.svg','d018b18e7ae61233755c0a7478017aa945b375f6','8aeb4ebef8411bab466c7e17b07de8a6aaea2a94','svg','image/svg+xml','teaserbox.svg','bf1018af6774857c65166af947e9fa178b7b05ae',287,1708625067,1708625066),
(51,0,1708625312,1708625312,0,0,'2',0,'/_assets/19b814ad90c7db12d898e4f4aedb0ee5/Icons/Backend/Mask/google_maps.svg','ab51c963fdb92de3b84b8ac4dbcb60b3c80cfa87','8aeb4ebef8411bab466c7e17b07de8a6aaea2a94','svg','image/svg+xml','google_maps.svg','11e8f25c2492b6c78868eb1b56154421b17e5917',377,1708625067,1708625066),
(52,0,1708625312,1708625312,0,0,'2',0,'/_assets/19b814ad90c7db12d898e4f4aedb0ee5/Icons/Backend/Mask/iframe_box.svg','e747a5ec2f406c35b568eedef9e4deb8019fa3ab','8aeb4ebef8411bab466c7e17b07de8a6aaea2a94','svg','image/svg+xml','iframe_box.svg','97c02e8e878c791728b71177762a21ef846c92af',296,1708625067,1708625066),
(53,0,1708625312,1708625312,0,0,'2',0,'/_assets/19b814ad90c7db12d898e4f4aedb0ee5/Icons/Backend/Mask/header.svg','aa0cf69236f8428a7a44c1294c189f12a42086d5','8aeb4ebef8411bab466c7e17b07de8a6aaea2a94','svg','image/svg+xml','header.svg','df165ab354be2a78cf1e85af7362074972e18ac9',321,1708625067,1708625066),
(54,0,1708625312,1708625312,0,0,'2',0,'/_assets/19b814ad90c7db12d898e4f4aedb0ee5/Icons/Backend/Mask/team.svg','87c389a626d7f8520bc0f0ca03fbc680190c12dc','8aeb4ebef8411bab466c7e17b07de8a6aaea2a94','svg','image/svg+xml','team.svg','5f24fb1613fd987e445451d8bfd54355504c9be3',748,1708625067,1708625066),
(55,0,1708625312,1708625312,0,0,'2',0,'/_assets/19b814ad90c7db12d898e4f4aedb0ee5/Icons/Backend/Mask/quote.svg','d94c808424dea9f970f0e8a05c609bdd4cb8dd4d','8aeb4ebef8411bab466c7e17b07de8a6aaea2a94','svg','image/svg+xml','quote.svg','224fb29657b5825b773099e3bc5c1cb904cdddfb',539,1708625067,1708625066),
(56,0,1708625347,1708625347,0,0,'2',0,'/_assets/19b814ad90c7db12d898e4f4aedb0ee5/Images/logo.svg','79b0f5ac0a2ff3b9a0a2e6f3ef29026d1eaaed58','f8a7e13b20ef3160fc7dbfffa4f26c169a980306','svg','image/svg+xml','logo.svg','5697f304843690165bc13d6f934239f77b09fcd6',24166,1708625067,1708625066),
(57,0,1709764363,1709764363,0,0,'2',0,'/_assets/19b814ad90c7db12d898e4f4aedb0ee5/Images/map-wall.jpg','fe7490daff5cce57d681595e9efdad18a613c2f9','f8a7e13b20ef3160fc7dbfffa4f26c169a980306','jpg','image/jpeg','map-wall.jpg','7ea49a48fc3ea8b57bd89a87fe5549b31ffac7e0',499095,1709763877,1709763866),
(58,0,1709764514,1709764514,0,1,'2',0,'/sample_data/Element_4.png','b11804e39203c12c03b6da79588850d79d2aef0d','3b538e039cddf8a176e8e29599eac1cf1735d941','png','image/png','Element_4.png','ee71d10dc30c558e4aab61f4a5b138a6d7d011e9',64697,1708879490,1708878077),
(59,0,1709984589,1709984589,0,0,'2',0,'/_assets/19b814ad90c7db12d898e4f4aedb0ee5/Icons/Backend/Mask/html_text.svg','9b1b497fa9f3477d9fb6a2019c00e3c675ce1cb0','8aeb4ebef8411bab466c7e17b07de8a6aaea2a94','svg','image/svg+xml','html_text.svg','64ef89a13c6b7020ce8a7108ba9e36bf0bf2b0c8',359,1709984526,1709984512),
(60,0,1710083612,1710083612,0,1,'2',0,'/sample_data/kasper.jpeg','d5402e61e01c53db7dc451eb3e02fbb0513aefa2','3b538e039cddf8a176e8e29599eac1cf1735d941','jpeg','image/jpeg','kasper.jpeg','42f383b36c0442632ef8f2b6dfa707cc3acf0baa',13985,1710002759,1710002759),
(61,0,1710092455,1710092455,0,0,'2',0,'/_assets/19b814ad90c7db12d898e4f4aedb0ee5/Icons/Backend/Mask/footer_links.svg','3b2f5e976589ad575a371667e6dac4b0f8771d14','8aeb4ebef8411bab466c7e17b07de8a6aaea2a94','svg','image/svg+xml','footer_links.svg','c61c5ed1d55a9aba11a18b60ea78f92a543efa2a',361,1710092448,1710092448),
(62,0,1715025050,1715025050,0,0,'2',0,'/_assets/b1daa9f744e27a67b87a3dd0366c1fa2/Images/logo.svg','40e386a721d21b442b7961b23043cf6a9ea47b5e','5de1ddc462fa93395a85bad17d1926c8fe346903','svg','image/svg+xml','logo.svg','5697f304843690165bc13d6f934239f77b09fcd6',24166,1715024429,1715021816),
(63,0,1715031939,1715031939,0,1,'2',0,'/sample_data/david-pisnoy-46juD4zY1XA-unsplash.jpg','c5fa8fa8f411ea189b2545d412ac39bdf149bfb6','3b538e039cddf8a176e8e29599eac1cf1735d941','jpg','image/jpeg','david-pisnoy-46juD4zY1XA-unsplash.jpg','d645c3ae44b665ea4e6b377e5ed92bfa7ea62bdd',803056,1715031939,1715031939),
(64,0,1715058942,1715058942,0,1,'2',0,'/sample_data/rabie-madaci-4iwG8QD17AE-unsplash.jpg','b23c4ac42635f66709b72b3eddf844218b15fa64','3b538e039cddf8a176e8e29599eac1cf1735d941','jpg','image/jpeg','rabie-madaci-4iwG8QD17AE-unsplash.jpg','cd9ad2b5f577c280367e3208519f3251ef2ff4a1',116450,1715058942,1715058942),
(65,0,1715066193,1715066193,0,1,'2',0,'/sample_data/ryland-dean-6k6N8HTrXyE-unsplash.jpg','9cf6d710454facf6dd19ccbb6e1999cad90eb444','3b538e039cddf8a176e8e29599eac1cf1735d941','jpg','image/jpeg','ryland-dean-6k6N8HTrXyE-unsplash.jpg','bd6585961fad04e0141041db3a485655512f51ab',360757,1715066193,1715066193);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(11) NOT NULL DEFAULT 0,
  `recursive` smallint(6) NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `file` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1705959216,1669973002,0,0,NULL,0,'{\"title\":\"\",\"description\":\"\",\"ranking\":\"\",\"keywords\":\"\",\"alternative\":\"\",\"caption\":\"\",\"download_name\":\"\",\"sys_language_uid\":\"\",\"creator\":\"\",\"creator_tool\":\"\",\"publisher\":\"\",\"source\":\"\",\"copyright\":\"\",\"language\":\"\",\"location_country\":\"\",\"location_region\":\"\",\"location_city\":\"\",\"latitude\":\"\",\"longitude\":\"\",\"content_creation_date\":\"\",\"content_modification_date\":\"\",\"visible\":\"\",\"status\":\"\",\"fe_groups\":\"\",\"categories\":\"\"}',0,0,0,0,1,NULL,2400,1600,'','Ein Schreibtisch, an dem zwei Personen sitzen.',0),
(2,0,1705959263,1669973002,0,0,NULL,0,'{\"title\":\"\",\"description\":\"\",\"ranking\":\"\",\"keywords\":\"\",\"alternative\":\"\",\"caption\":\"\",\"download_name\":\"\",\"sys_language_uid\":\"\",\"creator\":\"\",\"creator_tool\":\"\",\"publisher\":\"\",\"source\":\"\",\"copyright\":\"\",\"language\":\"\",\"location_country\":\"\",\"location_region\":\"\",\"location_city\":\"\",\"latitude\":\"\",\"longitude\":\"\",\"content_creation_date\":\"\",\"content_modification_date\":\"\",\"visible\":\"\",\"status\":\"\",\"fe_groups\":\"\",\"categories\":\"\"}',0,0,0,0,2,NULL,2400,1600,'','Ein Meetingraum hinter einer Glasscheibe.',0),
(3,0,1705959286,1669973002,0,0,NULL,0,'{\"title\":\"\",\"description\":\"\",\"ranking\":\"\",\"keywords\":\"\",\"alternative\":\"\",\"caption\":\"\",\"download_name\":\"\",\"sys_language_uid\":\"\",\"creator\":\"\",\"creator_tool\":\"\",\"publisher\":\"\",\"source\":\"\",\"copyright\":\"\",\"language\":\"\",\"location_country\":\"\",\"location_region\":\"\",\"location_city\":\"\",\"latitude\":\"\",\"longitude\":\"\",\"content_creation_date\":\"\",\"content_modification_date\":\"\",\"visible\":\"\",\"status\":\"\",\"fe_groups\":\"\",\"categories\":\"\"}',0,0,0,0,3,NULL,2400,1800,'','Die Fassade und Balkone eines modernen Mehrfamilienhauses.',0),
(4,0,1705959309,1669973002,0,0,NULL,0,'{\"title\":\"\",\"description\":\"\",\"ranking\":\"\",\"keywords\":\"\",\"alternative\":\"\",\"caption\":\"\",\"download_name\":\"\",\"sys_language_uid\":\"\",\"creator\":\"\",\"creator_tool\":\"\",\"publisher\":\"\",\"source\":\"\",\"copyright\":\"\",\"language\":\"\",\"location_country\":\"\",\"location_region\":\"\",\"location_city\":\"\",\"latitude\":\"\",\"longitude\":\"\",\"content_creation_date\":\"\",\"content_modification_date\":\"\",\"visible\":\"\",\"status\":\"\",\"fe_groups\":\"\",\"categories\":\"\"}',0,0,0,0,4,NULL,2400,3106,'','Eine Frau an ihrem Schreibtisch.',0),
(5,0,1705959298,1669973002,0,0,NULL,0,'{\"title\":\"\",\"description\":\"\",\"ranking\":\"\",\"keywords\":\"\",\"alternative\":\"\",\"caption\":\"\",\"download_name\":\"\",\"sys_language_uid\":\"\",\"creator\":\"\",\"creator_tool\":\"\",\"publisher\":\"\",\"source\":\"\",\"copyright\":\"\",\"language\":\"\",\"location_country\":\"\",\"location_region\":\"\",\"location_city\":\"\",\"latitude\":\"\",\"longitude\":\"\",\"content_creation_date\":\"\",\"content_modification_date\":\"\",\"visible\":\"\",\"status\":\"\",\"fe_groups\":\"\",\"categories\":\"\"}',0,0,0,0,5,NULL,2400,1600,'','Eine Skyline einer Stadt.',0),
(6,0,1705959320,1669973002,0,0,NULL,0,'{\"title\":\"\",\"description\":\"\",\"ranking\":\"\",\"keywords\":\"\",\"alternative\":\"\",\"caption\":\"\",\"download_name\":\"\",\"sys_language_uid\":\"\",\"creator\":\"\",\"creator_tool\":\"\",\"publisher\":\"\",\"source\":\"\",\"copyright\":\"\",\"language\":\"\",\"location_country\":\"\",\"location_region\":\"\",\"location_city\":\"\",\"latitude\":\"\",\"longitude\":\"\",\"content_creation_date\":\"\",\"content_modification_date\":\"\",\"visible\":\"\",\"status\":\"\",\"fe_groups\":\"\",\"categories\":\"\"}',0,0,0,0,6,NULL,2400,1600,'','Büroräume einer Agentur',0),
(8,0,1669973002,1669973002,0,0,NULL,0,'',0,0,0,0,8,NULL,0,0,NULL,NULL,0),
(9,0,1669973002,1669973002,0,0,NULL,0,'',0,0,0,0,9,NULL,0,0,NULL,NULL,0),
(10,0,1683489978,1669973002,0,0,NULL,0,'',0,0,0,0,10,NULL,119,56,NULL,NULL,0),
(11,0,1683489978,1669973002,0,0,NULL,0,'',0,0,0,0,11,NULL,126,88,NULL,NULL,0),
(12,0,1683489978,1669973002,0,0,NULL,0,'',0,0,0,0,12,NULL,154,76,NULL,NULL,0),
(13,0,1683489978,1669973002,0,0,NULL,0,'',0,0,0,0,13,NULL,190,47,NULL,NULL,0),
(14,0,1683489978,1669973002,0,0,NULL,0,'',0,0,0,0,14,NULL,201,39,NULL,NULL,0),
(15,0,1683489978,1669973002,0,0,NULL,0,'',0,0,0,0,15,NULL,0,0,NULL,NULL,0),
(17,0,1705959231,1669973002,0,0,NULL,0,'{\"title\":\"\",\"description\":\"\",\"ranking\":\"\",\"keywords\":\"\",\"alternative\":\"\",\"caption\":\"\",\"download_name\":\"\",\"sys_language_uid\":\"\",\"creator\":\"\",\"creator_tool\":\"\",\"publisher\":\"\",\"source\":\"\",\"copyright\":\"\",\"language\":\"\",\"location_country\":\"\",\"location_region\":\"\",\"location_city\":\"\",\"latitude\":\"\",\"longitude\":\"\",\"content_creation_date\":\"\",\"content_modification_date\":\"\",\"visible\":\"\",\"status\":\"\",\"fe_groups\":\"\",\"categories\":\"\"}',0,0,0,0,17,NULL,600,400,'','Ein grünes Blatt in dunklem Licht.',0),
(18,0,1705959247,1669973002,0,0,NULL,0,'{\"title\":\"\",\"description\":\"\",\"ranking\":\"\",\"keywords\":\"\",\"alternative\":\"\",\"caption\":\"\",\"download_name\":\"\",\"sys_language_uid\":\"\",\"creator\":\"\",\"creator_tool\":\"\",\"publisher\":\"\",\"source\":\"\",\"copyright\":\"\",\"language\":\"\",\"location_country\":\"\",\"location_region\":\"\",\"location_city\":\"\",\"latitude\":\"\",\"longitude\":\"\",\"content_creation_date\":\"\",\"content_modification_date\":\"\",\"visible\":\"\",\"status\":\"\",\"fe_groups\":\"\",\"categories\":\"\"}',0,0,0,0,18,NULL,2400,1600,'','Eine Wüste mit Sanddünen.',0),
(19,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,1,NULL,2500,1586,NULL,NULL,0),
(20,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,2,NULL,2500,1667,NULL,NULL,0),
(21,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,3,NULL,2500,1407,NULL,NULL,0),
(22,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,4,NULL,2500,1668,NULL,NULL,0),
(23,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,5,NULL,2500,1197,NULL,NULL,0),
(24,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,6,NULL,2500,1250,NULL,NULL,0),
(26,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,8,NULL,0,0,NULL,NULL,0),
(27,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,9,NULL,0,0,NULL,NULL,0),
(28,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,15,NULL,0,0,NULL,NULL,0),
(30,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,17,NULL,300,200,NULL,NULL,0),
(31,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,18,NULL,2000,1332,NULL,NULL,0),
(32,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,1,NULL,2500,1586,NULL,NULL,0),
(33,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,2,NULL,2500,1667,NULL,NULL,0),
(34,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,3,NULL,2500,1407,NULL,NULL,0),
(35,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,4,NULL,2500,1668,NULL,NULL,0),
(36,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,5,NULL,2500,1197,NULL,NULL,0),
(37,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,6,NULL,2500,1250,NULL,NULL,0),
(39,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,8,NULL,0,0,NULL,NULL,0),
(40,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,9,NULL,0,0,NULL,NULL,0),
(41,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,15,NULL,0,0,NULL,NULL,0),
(43,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,17,NULL,0,0,NULL,NULL,0),
(44,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,9,NULL,0,0,NULL,NULL,0),
(45,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,15,NULL,0,0,NULL,NULL,0),
(47,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,17,NULL,300,200,NULL,NULL,0),
(48,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,18,NULL,2000,1332,NULL,NULL,0),
(49,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,1,NULL,2500,1586,NULL,NULL,0),
(50,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,2,NULL,2500,1667,NULL,NULL,0),
(51,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,3,NULL,2500,1407,NULL,NULL,0),
(52,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,4,NULL,2500,1668,NULL,NULL,0),
(53,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,5,NULL,2500,1197,NULL,NULL,0),
(54,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,6,NULL,2500,1250,NULL,NULL,0),
(56,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,8,NULL,0,0,NULL,NULL,0),
(57,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,9,NULL,0,0,NULL,NULL,0),
(58,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,15,NULL,0,0,NULL,NULL,0),
(60,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,17,NULL,0,0,NULL,NULL,0),
(61,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,9,NULL,0,0,NULL,NULL,0),
(62,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,15,NULL,0,0,NULL,NULL,0),
(64,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,17,NULL,300,200,NULL,NULL,0),
(65,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,18,NULL,2000,1332,NULL,NULL,0),
(66,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,17,NULL,0,0,NULL,NULL,0),
(68,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,15,NULL,0,0,NULL,NULL,0),
(69,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,9,NULL,0,0,NULL,NULL,0),
(70,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,1,NULL,2500,1586,NULL,NULL,0),
(71,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,2,NULL,2500,1667,NULL,NULL,0),
(72,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,3,NULL,2500,1407,NULL,NULL,0),
(73,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,4,NULL,2500,1668,NULL,NULL,0),
(74,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,5,NULL,2500,1197,NULL,NULL,0),
(75,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,6,NULL,2500,1250,NULL,NULL,0),
(77,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,8,NULL,0,0,NULL,NULL,0),
(78,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,9,NULL,0,0,NULL,NULL,0),
(79,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,15,NULL,0,0,NULL,NULL,0),
(81,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,17,NULL,300,200,NULL,NULL,0),
(82,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,18,NULL,2000,1332,NULL,NULL,0),
(83,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,4,NULL,2500,1668,NULL,NULL,0),
(84,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,5,NULL,2500,1197,NULL,NULL,0),
(85,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,6,NULL,2500,1250,NULL,NULL,0),
(86,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,3,NULL,2500,1407,NULL,NULL,0),
(87,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,1,NULL,2500,1586,NULL,NULL,0),
(88,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,2,NULL,2500,1667,NULL,NULL,0),
(90,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,8,NULL,0,0,NULL,NULL,0),
(91,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,9,NULL,0,0,NULL,NULL,0),
(92,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,15,NULL,0,0,NULL,NULL,0),
(94,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,17,NULL,300,200,NULL,NULL,0),
(95,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,18,NULL,2000,1332,NULL,NULL,0),
(96,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,15,NULL,0,0,NULL,NULL,0),
(97,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,3,NULL,2000,1125,NULL,NULL,0),
(100,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,1,NULL,1620,1080,NULL,NULL,0),
(101,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,2,NULL,1620,1080,NULL,NULL,0),
(102,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,8,NULL,0,0,NULL,NULL,0),
(103,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,9,NULL,0,0,NULL,NULL,0),
(104,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,17,NULL,300,200,NULL,NULL,0),
(105,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,18,NULL,2000,1332,'Wasser und Wellen','Wasser',0),
(106,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,2,'Meeting',1620,1080,'Frau und Mann beim Brainstorming','Frau und Mann beim Brainstorming',0),
(107,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,1,'Schreibtisch',1620,1080,'Bild mit einem Schreibtisch auf dem ein Laptop und Kartons stehen','Bild mit einem Schreibtisch auf dem ein Laptop und Kartons stehen',0),
(108,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,18,'Wasser',1920,1280,'Wasser fotografiert unter der Oberfläche','Unterwasser',0),
(109,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,17,'Wasser',300,200,'Wasser fotografiert unter der Oberfläche','Unterwasser',0),
(110,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,8,NULL,0,0,NULL,NULL,0),
(111,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,9,NULL,0,0,NULL,NULL,0),
(112,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,18,NULL,2000,1332,NULL,NULL,0),
(113,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,17,NULL,300,200,NULL,NULL,0),
(115,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,15,NULL,0,0,NULL,NULL,0),
(116,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,9,NULL,0,0,NULL,NULL,0),
(117,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,8,NULL,0,0,NULL,NULL,0),
(119,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,2,NULL,1620,1080,NULL,NULL,0),
(120,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,1,NULL,1620,1080,NULL,NULL,0),
(121,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,3,NULL,2000,1125,NULL,NULL,0),
(122,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,18,NULL,2000,1332,NULL,NULL,0),
(123,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,17,NULL,300,200,NULL,NULL,0),
(125,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,15,NULL,0,0,NULL,NULL,0),
(126,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,9,NULL,0,0,NULL,NULL,0),
(127,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,8,NULL,0,0,NULL,NULL,0),
(129,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,6,NULL,2500,1250,NULL,NULL,0),
(130,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,5,NULL,2500,1197,NULL,NULL,0),
(131,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,4,NULL,2500,1668,NULL,NULL,0),
(132,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,3,NULL,2500,1407,NULL,NULL,0),
(133,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,2,NULL,2500,1667,NULL,NULL,0),
(134,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,1,NULL,2500,1586,NULL,NULL,0),
(135,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,18,NULL,2000,1332,NULL,NULL,0),
(136,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,17,NULL,300,200,NULL,NULL,0),
(138,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,15,NULL,0,0,NULL,NULL,0),
(139,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,9,NULL,0,0,NULL,NULL,0),
(140,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,17,NULL,0,0,NULL,NULL,0),
(142,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,15,NULL,0,0,NULL,NULL,0),
(143,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,9,NULL,0,0,NULL,NULL,0),
(144,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,8,NULL,0,0,NULL,NULL,0),
(146,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,6,NULL,2500,1250,NULL,NULL,0),
(147,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,5,NULL,2500,1197,NULL,NULL,0),
(148,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,4,NULL,2500,1668,NULL,NULL,0),
(149,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,3,NULL,2500,1407,NULL,NULL,0),
(150,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,2,NULL,2500,1667,NULL,NULL,0),
(151,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,1,NULL,2500,1586,NULL,NULL,0),
(152,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,18,NULL,2000,1332,NULL,NULL,0),
(153,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,17,NULL,300,200,NULL,NULL,0),
(155,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,15,NULL,0,0,NULL,NULL,0),
(156,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,9,NULL,0,0,NULL,NULL,0),
(157,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,17,NULL,0,0,NULL,NULL,0),
(159,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,15,NULL,0,0,NULL,NULL,0),
(160,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,9,NULL,0,0,NULL,NULL,0),
(161,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,8,NULL,0,0,NULL,NULL,0),
(163,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,6,NULL,2500,1250,NULL,NULL,0),
(164,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,5,NULL,2500,1197,NULL,NULL,0),
(165,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,4,NULL,2500,1668,NULL,NULL,0),
(166,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,3,NULL,2500,1407,NULL,NULL,0),
(167,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,2,NULL,2500,1667,NULL,NULL,0),
(168,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,1,NULL,2500,1586,NULL,NULL,0),
(169,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,18,NULL,2000,1332,NULL,NULL,0),
(170,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,17,NULL,300,200,NULL,NULL,0),
(172,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,15,NULL,0,0,NULL,NULL,0),
(173,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,9,NULL,0,0,NULL,NULL,0),
(174,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,17,NULL,0,0,NULL,NULL,0),
(176,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,15,NULL,0,0,NULL,NULL,0),
(177,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,9,NULL,0,0,NULL,NULL,0),
(178,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,8,NULL,0,0,NULL,NULL,0),
(180,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,6,NULL,2500,1250,NULL,NULL,0),
(181,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,5,NULL,2500,1197,NULL,NULL,0),
(182,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,4,NULL,2500,1668,NULL,NULL,0),
(183,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,3,NULL,2500,1407,NULL,NULL,0),
(184,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,2,NULL,2500,1667,NULL,NULL,0),
(185,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,1,NULL,2500,1586,NULL,NULL,0),
(186,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,18,NULL,2000,1332,NULL,NULL,0),
(187,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,17,NULL,300,200,NULL,NULL,0),
(189,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,15,NULL,0,0,NULL,NULL,0),
(190,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,9,NULL,0,0,NULL,NULL,0),
(191,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,8,NULL,0,0,NULL,NULL,0),
(193,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,6,NULL,2500,1250,NULL,NULL,0),
(194,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,5,NULL,2500,1197,NULL,NULL,0),
(195,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,4,NULL,2500,1668,NULL,NULL,0),
(196,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,3,NULL,2500,1407,NULL,NULL,0),
(197,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,2,NULL,2500,1667,NULL,NULL,0),
(198,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,1,NULL,2500,1586,NULL,NULL,0),
(199,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,14,NULL,201,39,NULL,NULL,0),
(200,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,13,NULL,190,47,NULL,NULL,0),
(201,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,12,NULL,154,76,NULL,NULL,0),
(202,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,11,NULL,126,88,NULL,NULL,0),
(203,0,1669973002,1669973002,0,0,NULL,0,'{\"file\":\"\"}',0,0,0,0,10,NULL,119,56,NULL,NULL,0),
(204,0,1669974516,1669974516,0,0,NULL,0,'',0,0,0,0,19,NULL,0,0,NULL,NULL,0),
(205,0,1669974516,1669974516,0,0,NULL,0,'',0,0,0,0,20,NULL,248,177,NULL,NULL,0),
(206,0,1669974555,1669974555,0,0,NULL,0,'',0,0,0,0,21,NULL,4190,2262,NULL,NULL,0),
(207,0,1683399033,1683399033,0,0,NULL,0,'',0,0,0,0,22,NULL,156,156,NULL,NULL,0),
(208,0,1683399033,1683399033,0,0,NULL,0,'',0,0,0,0,23,NULL,18,18,NULL,NULL,0),
(209,0,1683399033,1683399033,0,0,NULL,0,'',0,0,0,0,24,NULL,120,42,NULL,NULL,0),
(210,0,1683399033,1683399033,0,0,NULL,0,'',0,0,0,0,25,NULL,156,156,NULL,NULL,0),
(211,0,1705959274,1697309823,0,0,NULL,0,'{\"title\":\"\",\"description\":\"\",\"ranking\":\"\",\"keywords\":\"\",\"alternative\":\"\",\"caption\":\"\",\"download_name\":\"\",\"sys_language_uid\":\"\",\"creator\":\"\",\"creator_tool\":\"\",\"publisher\":\"\",\"source\":\"\",\"copyright\":\"\",\"language\":\"\",\"location_country\":\"\",\"location_region\":\"\",\"location_city\":\"\",\"latitude\":\"\",\"longitude\":\"\",\"content_creation_date\":\"\",\"content_modification_date\":\"\",\"visible\":\"\",\"status\":\"\",\"fe_groups\":\"\",\"categories\":\"\"}',0,0,0,0,26,NULL,2400,1600,'','Die Fassade eines modernen Bauwerkes.',0),
(212,0,1697360992,1697360992,0,0,NULL,0,'',0,0,0,0,27,NULL,248,177,NULL,NULL,0),
(213,0,1697361027,1697361027,0,0,NULL,0,'',0,0,0,0,28,NULL,4190,2262,NULL,NULL,0),
(214,0,1705787631,1705787631,0,0,NULL,0,'',0,0,0,0,29,NULL,156,156,NULL,NULL,0),
(215,0,1705787631,1705787631,0,0,NULL,0,'',0,0,0,0,30,NULL,18,18,NULL,NULL,0),
(216,0,1705787631,1705787631,0,0,NULL,0,'',0,0,0,0,31,NULL,120,42,NULL,NULL,0),
(217,0,1705787631,1705787631,0,0,NULL,0,'',0,0,0,0,32,NULL,156,156,NULL,NULL,0),
(218,0,1705959341,1705959341,0,0,NULL,0,'',0,0,0,0,33,NULL,2400,1656,NULL,NULL,0),
(219,0,1705959864,1705959864,0,0,NULL,0,'',0,0,0,0,34,NULL,0,0,NULL,NULL,0),
(220,0,1705959986,1705959986,0,0,NULL,0,'',0,0,0,0,35,'Vimeo | Video Power',2048,1152,NULL,NULL,0),
(222,0,1705960345,1705960345,0,0,NULL,0,'',0,0,0,0,37,'Introducing Apple Vision Pro',2048,1152,NULL,NULL,0),
(223,0,1705960847,1705960847,0,0,NULL,0,'',0,0,0,0,40,NULL,2400,1350,NULL,NULL,0),
(224,0,1705960847,1705960847,0,0,NULL,0,'',0,0,0,0,38,NULL,2400,1600,NULL,NULL,0),
(225,0,1705960847,1705960847,0,0,NULL,0,'',0,0,0,0,39,NULL,2400,1600,NULL,NULL,0),
(226,0,1705960899,1705960899,0,0,NULL,0,'',0,0,0,0,41,NULL,2400,1600,NULL,NULL,0),
(227,0,1705960981,1705960981,0,0,NULL,0,'',0,0,0,0,42,NULL,2400,1590,NULL,NULL,0),
(228,0,1705961588,1705961588,0,0,NULL,0,'',0,0,0,0,43,NULL,2400,1601,NULL,NULL,0),
(229,0,1705962051,1705962051,0,0,NULL,0,'',0,0,0,0,44,NULL,2400,1600,NULL,NULL,0),
(230,0,1708625194,1708625194,0,0,NULL,0,'',0,0,0,0,45,NULL,24,24,NULL,NULL,0),
(231,0,1708625312,1708625312,0,0,NULL,0,'',0,0,0,0,46,NULL,24,24,NULL,NULL,0),
(232,0,1708625312,1708625312,0,0,NULL,0,'',0,0,0,0,47,NULL,24,24,NULL,NULL,0),
(233,0,1708625312,1708625312,0,0,NULL,0,'',0,0,0,0,48,NULL,24,24,NULL,NULL,0),
(234,0,1708625312,1708625312,0,0,NULL,0,'',0,0,0,0,49,NULL,24,24,NULL,NULL,0),
(235,0,1708625312,1708625312,0,0,NULL,0,'',0,0,0,0,50,NULL,24,24,NULL,NULL,0),
(236,0,1708625312,1708625312,0,0,NULL,0,'',0,0,0,0,51,NULL,24,24,NULL,NULL,0),
(237,0,1708625312,1708625312,0,0,NULL,0,'',0,0,0,0,52,NULL,24,24,NULL,NULL,0),
(238,0,1708625312,1708625312,0,0,NULL,0,'',0,0,0,0,53,NULL,24,24,NULL,NULL,0),
(239,0,1708625312,1708625312,0,0,NULL,0,'',0,0,0,0,54,NULL,24,24,NULL,NULL,0),
(240,0,1708625312,1708625312,0,0,NULL,0,'',0,0,0,0,55,NULL,24,24,NULL,NULL,0),
(241,0,1708625347,1708625347,0,0,NULL,0,'',0,0,0,0,56,NULL,248,177,NULL,NULL,0),
(242,0,1709764362,1709764362,0,0,NULL,0,'',0,0,0,0,57,NULL,4190,2262,NULL,NULL,0),
(243,0,1709764514,1709764514,0,0,NULL,0,'',0,0,0,0,58,NULL,750,271,NULL,NULL,0),
(244,0,1709984589,1709984589,0,0,NULL,0,'',0,0,0,0,59,NULL,24,24,NULL,NULL,0),
(245,0,1710083612,1710083612,0,0,NULL,0,'',0,0,0,0,60,NULL,264,264,NULL,NULL,0),
(246,0,1710092455,1710092455,0,0,NULL,0,'',0,0,0,0,61,NULL,24,24,NULL,NULL,0),
(247,0,1715025050,1715025050,0,0,NULL,0,'',0,0,0,0,62,NULL,248,177,NULL,NULL,0),
(248,0,1715031939,1715031939,0,0,NULL,0,'',0,0,0,0,63,NULL,1920,2560,NULL,NULL,0),
(249,0,1715058942,1715058942,0,0,NULL,0,'',0,0,0,0,64,NULL,1920,1280,NULL,NULL,0),
(250,0,1715066193,1715066193,0,0,NULL,0,'',0,0,0,0,65,NULL,1920,1272,NULL,NULL,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=2880 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES
(2689,1711901121,1711901121,0,56,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','5697f304843690165bc13d6f934239f77b09fcd6','Image.CropScaleMask','9a505a3cf2',248,177),
(2808,1711967510,1711967510,0,57,'/typo3temp/assets/_processed_/f/5/csm_map-wall_ee9d2c312a.webp','csm_map-wall_ee9d2c312a.webp',NULL,'a:8:{s:5:\"width\";i:1920;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;s:13:\"fileExtension\";s:4:\"webp\";}','f6445df42fdc80955eb33e261f317485753fde20','7ea49a48fc3ea8b57bd89a87fe5549b31ffac7e0','Image.CropScaleMask','ee9d2c312a',1920,1037),
(2827,1715025050,1715025050,0,62,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','5697f304843690165bc13d6f934239f77b09fcd6','Image.CropScaleMask','6a2f0bea87',248,177);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `description` text DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `crop` varchar(4000) NOT NULL DEFAULT '',
  `autoplay` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES
(104,1,1715031954,1715031954,0,0,0,0,NULL,'',0,0,0,0,63,78,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":0.421,\"width\":0.9973333333333333,\"x\":0,\"y\":0.462},\"selectedRatio\":\"16:9\",\"focusArea\":null}}',0),
(105,1,1715065332,1715065327,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,64,81,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(106,1,1715072591,1715066206,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,65,83,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"height\":0.7677224736048266,\"width\":1,\"x\":0,\"y\":0.03469079939668175},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(107,47,1715073644,1715073644,0,0,0,0,NULL,'',0,0,0,0,64,94,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `driver` tinytext DEFAULT NULL,
  `configuration` text DEFAULT NULL,
  `is_default` smallint(6) NOT NULL DEFAULT 0,
  `is_browsable` smallint(6) NOT NULL DEFAULT 0,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(6) NOT NULL DEFAULT 0,
  `is_online` smallint(6) NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(6) NOT NULL DEFAULT 1,
  `processingfolder` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1669973002,1669973002,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
INSERT INTO `sys_filemounts` VALUES
(1,0,1711960026,0,0,256,'','Fileadmin',0,'1:/');
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(32) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
INSERT INTO `sys_http_report` VALUES
('703e6316-efca-49ff-a3f7-f3037cfb164b',0,1705830438,1705830438,'csp-report','backend',1705830435192662,'{\"addr\":\"192.168.167.0\",\"agent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/120.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/buffpackage.ddev.site\\/typo3\\/module\\/web\\/ig-slug\\/rebuild\\/Slug\\/list?id=1\",\"referrer\":\"https:\\/\\/buffpackage.ddev.site\\/typo3\\/module\\/web\\/ig-slug\\/rebuild?id=1\",\"violated-directive\":\"script-src-elem\",\"effective-directive\":\"script-src-elem\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-lG_E1KWAXYD_8yJcwCNsDhbaiXB-IJLTNMJxqlAw1RpxKz1XKDfDdg\' data: \'unsafe-eval\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/buffpackage.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1705830435192662\",\"disposition\":\"enforce\",\"blocked-uri\":\"inline\",\"line-number\":1,\"source-file\":\"https:\\/\\/buffpackage.ddev.site\\/typo3\\/module\\/web\\/ig-slug\\/rebuild\\/Slug\\/list\",\"status-code\":200,\"script-sample\":\"javascript:void(0)\"}','87634999bfb84e191e8b1c879d852691bff57401');
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `NEWid` varchar(30) NOT NULL DEFAULT '',
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `channel` (`channel`),
  KEY `level` (`level`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` mediumtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_redirect`
--

DROP TABLE IF EXISTS `sys_redirect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_redirect` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `source_host` varchar(255) NOT NULL DEFAULT '',
  `source_path` varchar(2048) NOT NULL DEFAULT '',
  `is_regexp` smallint(5) unsigned NOT NULL DEFAULT 0,
  `protected` smallint(5) unsigned NOT NULL DEFAULT 0,
  `force_https` smallint(5) unsigned NOT NULL DEFAULT 0,
  `respect_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `keep_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `target` varchar(2048) NOT NULL DEFAULT '',
  `target_statuscode` int(11) NOT NULL DEFAULT 307,
  `hitcount` int(11) NOT NULL DEFAULT 0,
  `lasthiton` int(11) NOT NULL DEFAULT 0,
  `disable_hitcount` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `creation_type` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_source` (`source_host`(80),`source_path`(80)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_redirect`
--

LOCK TABLES `sys_redirect` WRITE;
/*!40000 ALTER TABLE `sys_redirect` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_redirect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) NOT NULL DEFAULT '',
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recuid` int(11) NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `ref_table` varchar(255) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`(100),`recuid`),
  KEY `lookup_uid` (`ref_table`(100),`ref_uid`),
  KEY `lookup_string` (`ref_string`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('005c071d451053d8e244848533c19a62','sys_file_metadata',232,'file','','','',0,0,'sys_file',47,''),
('007244a88a62dda0f1a31a94d7d1593d','sys_file_metadata',186,'file','','','',0,0,'sys_file',18,''),
('00d766e351944a9ac28974db00461c60','sys_file',18,'metadata','','','',6,0,'sys_file_metadata',105,''),
('00f6f5898d3354c88c6365fd64de53c9','sys_file',40,'storage','','','',0,0,'sys_file_storage',1,''),
('011e885c4389cfb5960d7373702705ab','sys_file_metadata',249,'file','','','',0,0,'sys_file',64,''),
('028194e1ff16a180fee12eea88d4e929','sys_file',23,'metadata','','','',0,0,'sys_file_metadata',208,''),
('02b0c0d38dc06c68d13aa2a83920c6cf','sys_file',6,'metadata','','','',9,0,'sys_file_metadata',180,''),
('03111e4fde8118191801b7cb8873e086','sys_file_metadata',75,'file','','','',0,0,'sys_file',6,''),
('031ceb75f4e99f1d894ff8319ba5871a','sys_file_metadata',121,'file','','','',0,0,'sys_file',3,''),
('03e925867c5ac09b11c9c5094df32965','sys_file',35,'storage','','','',0,0,'sys_file_storage',1,''),
('03ea9d68a464b5f181a4842af320e0bb','sys_file_metadata',197,'file','','','',0,0,'sys_file',2,''),
('04bb4748d054506a3aa7d95f67f1c982','sys_file_metadata',90,'file','','','',0,0,'sys_file',8,''),
('04d60dcaa8726b6eb9fa185fd7477f4e','sys_file',6,'metadata','','','',4,0,'sys_file_metadata',75,''),
('0793b4c181d7be470a533f2b26d276a9','sys_file',59,'metadata','','','',0,0,'sys_file_metadata',244,''),
('08978a3a636f07c945b6445bf1a0e642','sys_file',3,'metadata','','','',1,0,'sys_file_metadata',21,''),
('090d5cdd79a52759778d84e34ed9c3f9','sys_file',17,'metadata','','','',17,0,'sys_file_metadata',170,''),
('09c178778e7f553e05cc34fe6a2ba120','sys_file',38,'storage','','','',0,0,'sys_file_storage',1,''),
('09da0451691afe59d87bcc62d1fa324d','sys_file',5,'metadata','','','',4,0,'sys_file_metadata',74,''),
('0a59b6aabacf635f74cbc5e4ded1713f','sys_file',17,'metadata','','','',12,0,'sys_file_metadata',123,''),
('0a9edac43e5ead3d212584f6d743feaa','sys_file',3,'metadata','','','',2,0,'sys_file_metadata',34,''),
('0aa8163577106dfb4e62efbe38933919','sys_file',18,'metadata','','','',5,0,'sys_file_metadata',95,''),
('0bc75fc48a18f1b7592b49955076fe97','sys_file',6,'storage','','','',0,0,'sys_file_storage',1,''),
('0bf363f198352c1f251386c0a559f6ac','sys_file',3,'metadata','','','',0,0,'sys_file_metadata',3,''),
('0d8564b4a15374da09c96f38335f5edd','sys_file_metadata',24,'file','','','',0,0,'sys_file',6,''),
('0f682e9343e355108c807c0b2583f64c','sys_file',9,'metadata','','','',7,0,'sys_file_metadata',78,''),
('0f96894a5db623ca0b3040c841b75ef6','sys_file',8,'metadata','','','',6,0,'sys_file_metadata',102,''),
('1032abef5a7230a66efd427aae45260f','sys_file',4,'metadata','','','',6,0,'sys_file_metadata',131,''),
('1064c87d751a0f7b2f01d8bc8768c4c7','sys_file_metadata',138,'file','','','',0,0,'sys_file',15,''),
('1104753725fdd346611f0f250bc5383a','sys_file',8,'metadata','','','',1,0,'sys_file_metadata',26,''),
('119d89ea7662d165111893653811a104','sys_file_metadata',233,'file','','','',0,0,'sys_file',48,''),
('134409361025e68099360a2d4b933d1a','sys_file',4,'metadata','','','',8,0,'sys_file_metadata',165,''),
('1379d00653af24c62109fe29c47cb0d5','sys_file',8,'metadata','','','',5,0,'sys_file_metadata',90,''),
('13aaa63a0ffb7dffbe8c45a30e2c9f43','sys_file_metadata',164,'file','','','',0,0,'sys_file',5,''),
('13e65698462d42b1dc6c1dd11691f0a7','sys_file',64,'metadata','','','',0,0,'sys_file_metadata',249,''),
('13f8abb19f869b726902e45921fe8066','sys_file_metadata',101,'file','','','',0,0,'sys_file',2,''),
('13fdf525a800d1920b4919b3263d74fe','sys_file',4,'metadata','','','',5,0,'sys_file_metadata',83,''),
('140145241be77c77978bbb730e9af70d','sys_file_metadata',155,'file','','','',0,0,'sys_file',15,''),
('1435343861399c1e166091b7dc0be755','sys_file',11,'metadata','','','',0,0,'sys_file_metadata',11,''),
('14bba0ac72c46e10184e300e5e4368ca','sys_file_metadata',52,'file','','','',0,0,'sys_file',4,''),
('14bd44a527de2b3323acfcfc6a5723f4','sys_file_metadata',166,'file','','','',0,0,'sys_file',3,''),
('15597f65d7df3a40d1e792514c91c69f','sys_file',10,'storage','','','',0,0,'sys_file_storage',1,''),
('1699e4984e1e5b8be5f05d9e4fcbe1f3','sys_file',17,'metadata','','','',19,0,'sys_file_metadata',187,''),
('176ace435f70f11dc38f7ca36a47f220','sys_file_metadata',119,'file','','','',0,0,'sys_file',2,''),
('176e7df7d6b406b9e4a3c14905492659','sys_file',18,'metadata','','','',7,0,'sys_file_metadata',108,''),
('178b288a284400d8a3a1bcf2a39acb7d','sys_file_metadata',109,'file','','','',0,0,'sys_file',17,''),
('17ce607eb379d455891935728eebe642','sys_file',61,'metadata','','','',0,0,'sys_file_metadata',246,''),
('17ec1c755094ff77bf4ddb93521aca8b','sys_file',60,'storage','','','',0,0,'sys_file_storage',1,''),
('17edff71dc0fdb64fbfa59de4d16e784','sys_file',18,'metadata','','','',13,0,'sys_file_metadata',186,''),
('18a8a74fb1cf112250251c7f2fa004eb','sys_file_metadata',54,'file','','','',0,0,'sys_file',6,''),
('193c77d88accb2c40b52476d77ae0a4c','sys_file_metadata',14,'file','','','',0,0,'sys_file',14,''),
('196ed7332eeef3acd6b4110a18f0801b','sys_file',19,'metadata','','','',0,0,'sys_file_metadata',204,''),
('199cfc2aec855c3ebb622a6026c9523f','sys_file_metadata',143,'file','','','',0,0,'sys_file',9,''),
('1a5a61a24075dfc08f419e013ceab402','sys_file',1,'metadata','','','',9,0,'sys_file_metadata',134,''),
('1a68fa4560dbcd8fd292dfe594b7ab7b','sys_file',18,'metadata','','','',8,0,'sys_file_metadata',112,''),
('1ab67d3a3721d11af9caa22839aa41ef','sys_file',22,'metadata','','','',0,0,'sys_file_metadata',207,''),
('1b88878464346b7c664fc1f72cc78d60','sys_file_metadata',53,'file','','','',0,0,'sys_file',5,''),
('1bb57da61d645489bcbc5bd6e9ee41eb','sys_file',24,'metadata','','','',0,0,'sys_file_metadata',209,''),
('1c32885b836480780b17d13c02b65b7b','sys_file',8,'metadata','','','',11,0,'sys_file_metadata',161,''),
('1c7d063c9fe6f5905db23af8fcea1aaa','sys_file',17,'metadata','','','',18,0,'sys_file_metadata',174,''),
('1c9b8784c1518ef7b22704c4fc698ca9','sys_file',2,'storage','','','',0,0,'sys_file_storage',1,''),
('1cd61e2789a8b4614f313b9ebaa6a199','sys_file_metadata',47,'file','','','',0,0,'sys_file',17,''),
('1cfc87f48042a5b006bfa03987854083','sys_file',13,'metadata','','','',1,0,'sys_file_metadata',200,''),
('1e1a0a63de1ef6ff1ac47be35d01e7d3','sys_file_metadata',177,'file','','','',0,0,'sys_file',9,''),
('1f0c820c0dbbb5e216512d0a5c9f15a5','sys_file_metadata',33,'file','','','',0,0,'sys_file',2,''),
('1f700cd533c1d5ed201aea358f10286d','sys_file',2,'metadata','','','',2,0,'sys_file_metadata',33,''),
('1fda583505d1504f2be41ded771b3d72','sys_file_metadata',234,'file','','','',0,0,'sys_file',49,''),
('1fe6b57abe16f80f70e4b5cd8c19f7fa','sys_file_metadata',65,'file','','','',0,0,'sys_file',18,''),
('201dc1e0bfcfe2f0da28f73af08e60c0','sys_file_metadata',2,'file','','','',0,0,'sys_file',2,''),
('2035702120a34c5d5fa04e9e690a76f1','sys_file',4,'metadata','','','',7,0,'sys_file_metadata',148,''),
('205ee1e7af4e30938944dda3fc6a9e60','sys_file',13,'storage','','','',0,0,'sys_file_storage',1,''),
('208beee30966b76498a00167dbd15d78','sys_file',41,'storage','','','',0,0,'sys_file_storage',1,''),
('2146d95f1c8484d1ddebed79b7f4125f','sys_file',38,'metadata','','','',0,0,'sys_file_metadata',224,''),
('21903c63ea15220ce84a1b308e9efe3d','sys_file_metadata',217,'file','','','',0,0,'sys_file',32,''),
('21d732894f6530a631e178b8c76eecbb','sys_file',18,'metadata','','','',3,0,'sys_file_metadata',65,''),
('22534581db65e11c746941c13d0363b5','sys_file_metadata',173,'file','','','',0,0,'sys_file',9,''),
('24d47b29aa969cf4db8635e76dd1c386','sys_file',3,'storage','','','',0,0,'sys_file_storage',1,''),
('268a6fd80d2b91928c2a91c38556c2c2','sys_file',18,'metadata','','','',4,0,'sys_file_metadata',82,''),
('26df004b3189d3d28bdd6d7c05cd61bf','sys_file_metadata',163,'file','','','',0,0,'sys_file',6,''),
('280c42bd3ed2495839d66335ca762664','sys_file',15,'metadata','','','',12,0,'sys_file_metadata',138,''),
('2897b9c36b6943b02b176dc47f69c672','sys_file',42,'storage','','','',0,0,'sys_file_storage',1,''),
('289f2ba53f2c05a2b6b5658ea0bc8f0c','sys_file',5,'metadata','','','',7,0,'sys_file_metadata',147,''),
('28e517f11edf074f821b28d5e8645da0','sys_file_metadata',73,'file','','','',0,0,'sys_file',4,''),
('299772fb2aeec30794c35b1c0f27c213','sys_file_metadata',88,'file','','','',0,0,'sys_file',2,''),
('2ae12c04d24ac14601aab3db7a005065','sys_file_metadata',12,'file','','','',0,0,'sys_file',12,''),
('2c12b1cf9f756299fdb1f3c269f259d9','sys_file_metadata',248,'file','','','',0,0,'sys_file',63,''),
('2cf48d9a5e85e16d76f14be5accf2808','sys_file_metadata',30,'file','','','',0,0,'sys_file',17,''),
('2da7bab0f2bf4f858494478c377633f3','sys_file_metadata',224,'file','','','',0,0,'sys_file',38,''),
('2db6c3a99d5be7af8fee0947c22a9d1d','sys_file',9,'metadata','','','',17,0,'sys_file_metadata',173,''),
('2f03a937dfeadc422d9e4d31d5c70233','sys_file_metadata',242,'file','','','',0,0,'sys_file',57,''),
('31a9634b589512e00accb2854a891547','sys_file_metadata',50,'file','','','',0,0,'sys_file',2,''),
('3431de2669c2e342a2225be49b9e1cd8','tt_content',94,'image','','','',0,0,'sys_file_reference',107,''),
('34a5b52c68be1e1b862cd07b73364aeb','sys_file_metadata',214,'file','','','',0,0,'sys_file',29,''),
('34b0a8a6080cf05ec27130045f6fefe7','sys_file',43,'metadata','','','',0,0,'sys_file_metadata',228,''),
('34be8299e1120dc362450a2e190cdad5','sys_file_metadata',83,'file','','','',0,0,'sys_file',4,''),
('36d38e56abd8e76855eba292715b43b3','sys_file_metadata',136,'file','','','',0,0,'sys_file',17,''),
('37808fe504821adacb08fc6115b965ff','sys_file_metadata',190,'file','','','',0,0,'sys_file',9,''),
('380f5dc8fe0dadf1b11f8c6b92e471cf','sys_file_metadata',125,'file','','','',0,0,'sys_file',15,''),
('39433ea4a82060704109046e4828d3c8','sys_file',1,'storage','','','',0,0,'sys_file_storage',1,''),
('3b3d88c84b4cf5aa43eb76c255378b66','sys_file_metadata',97,'file','','','',0,0,'sys_file',3,''),
('3b45c979f8a0af08a820b8b82f996ae3','sys_file_metadata',95,'file','','','',0,0,'sys_file',18,''),
('3b8653402cf86ba069567712e817012f','sys_file',15,'metadata','','','',7,0,'sys_file_metadata',79,''),
('3bfbc2e0debd0d0a130993fb8403cee1','sys_file_metadata',34,'file','','','',0,0,'sys_file',3,''),
('3c04889d5e9dff80d8339dfbd508ab13','sys_file',10,'metadata','','','',0,0,'sys_file_metadata',10,''),
('3ca5d01f770a8ca62e0bb20668864e69','sys_file',15,'metadata','','','',8,0,'sys_file_metadata',92,''),
('3d5e2bd3ceee92c7c79e84adbde8911e','sys_file',21,'metadata','','','',0,0,'sys_file_metadata',206,''),
('3d7ca702f4a43204d05adaf8df84cac8','sys_file',50,'metadata','','','',0,0,'sys_file_metadata',235,''),
('3de91a90831bfc9579262d308b4bd4cd','sys_file_metadata',35,'file','','','',0,0,'sys_file',4,''),
('3f0a9bda73df91910747f5ec297d2d81','sys_file',9,'metadata','','','',13,0,'sys_file_metadata',139,''),
('3f895c6b05f5475c815e80a6516037ae','sys_file',29,'metadata','','','',0,0,'sys_file_metadata',214,''),
('3ff5c1b03524aac69e8ae1c4a85d3644','sys_file',8,'metadata','','','',3,0,'sys_file_metadata',56,''),
('40b1ae0e1b5dbe7fe99439c532767c91','sys_file',46,'metadata','','','',0,0,'sys_file_metadata',231,''),
('423625973acb1a34275fa48b74f76f78','sys_file',8,'metadata','','','',0,0,'sys_file_metadata',8,''),
('42b4fa2045bbf682f947f7f15aae73bf','sys_file_metadata',170,'file','','','',0,0,'sys_file',17,''),
('448611b4664f57d23ddcc9b641299687','sys_file',17,'metadata','','','',0,0,'sys_file_metadata',17,''),
('4554abcfdd30954a20023042e325803b','sys_file_metadata',94,'file','','','',0,0,'sys_file',17,''),
('456405f3b3d41dfa7c3fdac37637aa65','sys_file',2,'metadata','','','',1,0,'sys_file_metadata',20,''),
('4576e61add4b2a47199469b5570e3b68','sys_file',25,'metadata','','','',0,0,'sys_file_metadata',210,''),
('45b1e64bfadf6d2df52b04f19db94d08','sys_file',1,'metadata','','','',13,0,'sys_file_metadata',198,''),
('45d3b527060c2fa8b1be5e7ba3dd6f70','sys_file',34,'metadata','','','',0,0,'sys_file_metadata',219,''),
('466be21af3a146f8bd9d1163ef0f7e8e','sys_file',12,'metadata','','','',1,0,'sys_file_metadata',201,''),
('4686cee24264084cf06dcf750835f6ec','sys_file',17,'metadata','','','',13,0,'sys_file_metadata',136,''),
('46ab32182f44efca0f7fb8a85d0d6ed5','sys_file_metadata',113,'file','','','',0,0,'sys_file',17,''),
('471261ee81bc0f30f0396f3c5de9d78c','sys_file_metadata',246,'file','','','',0,0,'sys_file',61,''),
('484cfd2e139499fba15cabbbdbc01034','sys_file_reference',106,'uid_local','','','',0,0,'sys_file',65,''),
('490ac7a81a9d9e65b95c0bd4268020ee','sys_file',26,'metadata','','','',0,0,'sys_file_metadata',211,''),
('4918619cff7d234a11bd008050dbc5ee','sys_file_metadata',131,'file','','','',0,0,'sys_file',4,''),
('4937b0570de0cdcc67289f2299bc9595','sys_file',9,'metadata','','','',4,0,'sys_file_metadata',57,''),
('499d32b762de8386cb98dc59db7caee6','sys_file',39,'storage','','','',0,0,'sys_file_storage',1,''),
('4a5c4a9472129e7942562a00d8916086','sys_file',1,'metadata','','','',4,0,'sys_file_metadata',70,''),
('4a62dca114d4ca4cf70ed9b0bf6e0139','sys_file',17,'metadata','','','',7,0,'sys_file_metadata',81,''),
('4ab1b372090f0beca8412d33ab69ed5b','sys_file_metadata',115,'file','','','',0,0,'sys_file',15,''),
('4af1b25c9a2f9a55a32db1c24f26269f','sys_file',2,'metadata','','','',5,0,'sys_file_metadata',88,''),
('4b914770e8409c054d989e0935bfc9f5','sys_file',9,'metadata','','','',16,0,'sys_file_metadata',160,''),
('4bb78688c120ed29b767e2ae1c34537b','sys_file_metadata',71,'file','','','',0,0,'sys_file',2,''),
('4bf027271102de7d004593506ea11d96','sys_file',14,'metadata','','','',0,0,'sys_file_metadata',14,''),
('4c63ebdb08ea2c94e08d97c0ccb83ffe','sys_file',2,'metadata','','','',7,0,'sys_file_metadata',106,''),
('4e390510ac9e5c01d90c452c9052822d','tt_content',81,'image','','','',0,0,'sys_file_reference',105,''),
('4ec0551a841f0d2d061e06168cfc6e36','sys_file',4,'metadata','','','',3,0,'sys_file_metadata',52,''),
('4fb8a56827a2c433b193c1d1416ef5df','sys_file_metadata',181,'file','','','',0,0,'sys_file',5,''),
('507ebb6af0d73005fea487dd8682be6f','sys_file_metadata',140,'file','','','',0,0,'sys_file',17,''),
('511952f3cbe95b0ad2c57e0c49d3953f','sys_file_metadata',111,'file','','','',0,0,'sys_file',9,''),
('52b4608e3a074c29df0a190a39888959','sys_file_metadata',103,'file','','','',0,0,'sys_file',9,''),
('539f6714b227af2172bae520934de988','sys_file_metadata',70,'file','','','',0,0,'sys_file',1,''),
('53dd425a6503ad6d76c286c41c00e056','sys_file',18,'metadata','','','',10,0,'sys_file_metadata',135,''),
('5430866e5904d20f26780b1e7148b396','sys_file',31,'metadata','','','',0,0,'sys_file_metadata',216,''),
('5677c537f5515d1e48260527bd26b477','sys_file',5,'metadata','','','',5,0,'sys_file_metadata',84,''),
('56e4e8537bcee3014e2ac130b0b35a42','sys_file',15,'storage','','','',0,0,'sys_file_storage',1,''),
('58b0b23572e4f772e262c73a399cde1e','sys_file',9,'metadata','','','',18,0,'sys_file_metadata',177,''),
('5907ebd6b7d991917e98610c9ded4855','sys_file',11,'metadata','','','',1,0,'sys_file_metadata',202,''),
('59116416a8b25709aeb866697b104710','sys_file',4,'metadata','','','',9,0,'sys_file_metadata',182,''),
('5940221a5108ec95a9cb87bef216cb0a','sys_file_metadata',120,'file','','','',0,0,'sys_file',1,''),
('5954be285aaa9c7d8dfa1700ccf1080b','sys_file_metadata',122,'file','','','',0,0,'sys_file',18,''),
('5a361da4e8df275a58817cb6d238a2d7','sys_file',8,'metadata','','','',13,0,'sys_file_metadata',191,''),
('5b4749e3eb58cef7dd6af96613cb5cba','sys_file',8,'metadata','','','',12,0,'sys_file_metadata',178,''),
('5b8ae43e1a66bd3cf9cda97f15025829','sys_file',53,'metadata','','','',0,0,'sys_file_metadata',238,''),
('5bca7aa3b44f8d74099c6ad2e9862af1','sys_file',58,'storage','','','',0,0,'sys_file_storage',1,''),
('5c4e382299512b4b25ff18a387cc8e10','sys_file',9,'metadata','','','',2,0,'sys_file_metadata',40,''),
('5d20ee6d120bc66f46b8a1e567f7099b','sys_file_metadata',150,'file','','','',0,0,'sys_file',2,''),
('5df4e654314c1179dad47ed25d08eaef','sys_file',15,'metadata','','','',2,0,'sys_file_metadata',41,''),
('5eed05551b02b3d0d4b26fb92a25952b','sys_file',3,'metadata','','','',5,0,'sys_file_metadata',86,''),
('5f0896b94ac414adad47fb63548f177f','sys_file_metadata',77,'file','','','',0,0,'sys_file',8,''),
('5fb4345cbfb2173c27963d955903bb32','sys_file',1,'metadata','','','',11,0,'sys_file_metadata',168,''),
('60b63b75f418e051774f88f1884ecf80','sys_file_metadata',69,'file','','','',0,0,'sys_file',9,''),
('612b5cb90cefce163be86550f529a235','sys_file_metadata',151,'file','','','',0,0,'sys_file',1,''),
('61977478bd2dfb37904b8a4f7a50dd00','sys_file',13,'metadata','','','',0,0,'sys_file_metadata',13,''),
('61cf560ee7a0ec22537c74c63d4bd2ae','sys_file',3,'metadata','','','',4,0,'sys_file_metadata',72,''),
('61f32eebf5b38cb311f467d912a316bb','sys_file_metadata',227,'file','','','',0,0,'sys_file',42,''),
('63cb72d8a0dabf1b22d9dd738fbe4023','sys_file_metadata',210,'file','','','',0,0,'sys_file',25,''),
('63cbcd5625ef74e8252c29cc0145c690','sys_file',12,'storage','','','',0,0,'sys_file_storage',1,''),
('6439d62aa13f2f6a677907bfb9e4a272','sys_file_metadata',240,'file','','','',0,0,'sys_file',55,''),
('649c4f8c25628c4db1da3211b8d4f94a','sys_file',17,'metadata','','','',9,0,'sys_file_metadata',104,''),
('65648c71c1269133729d392d58613fe6','sys_file',39,'metadata','','','',0,0,'sys_file_metadata',225,''),
('658bd33b27e407ce87630f2f08bf1dd6','sys_file_metadata',218,'file','','','',0,0,'sys_file',33,''),
('65d2b4ebf36e398964d619c346ce0956','sys_file_metadata',51,'file','','','',0,0,'sys_file',3,''),
('673032fdd507e7f724529f3289b207f4','sys_file',18,'metadata','','','',0,0,'sys_file_metadata',18,''),
('676a1e7cb69b5a652d153dd2e18cdee0','sys_file_metadata',133,'file','','','',0,0,'sys_file',2,''),
('6853c1601615d7bfe0342d2bde3a955d','sys_file',8,'metadata','','','',10,0,'sys_file_metadata',144,''),
('68a3b1f832fe83e5ac760de25f20a93d','sys_file',1,'metadata','','','',12,0,'sys_file_metadata',185,''),
('6904306b8572e7b1d523d8ec7b8cd7e6','sys_file',17,'metadata','','','',8,0,'sys_file_metadata',94,''),
('692e129d0a6ae1105f43e3627f14e64d','sys_file',8,'storage','','','',0,0,'sys_file_storage',1,''),
('69540da8ea50b482ec3a208bc00e02df','sys_file_metadata',28,'file','','','',0,0,'sys_file',15,''),
('69774320e1bff6114177f689979000e1','sys_file_metadata',160,'file','','','',0,0,'sys_file',9,''),
('69ffd09a74242f08e1e59d237b69cf89','sys_file',3,'metadata','','','',10,0,'sys_file_metadata',166,''),
('6a07fc91671364f3dbcbd2707e651275','sys_file',15,'metadata','','','',11,0,'sys_file_metadata',125,''),
('6a6afbc22cce8391498d35fe148f0020','sys_file_metadata',43,'file','','','',0,0,'sys_file',17,''),
('6b2adfc6648e611faac97b9539531abd','sys_file',41,'metadata','','','',0,0,'sys_file_metadata',226,''),
('6b31f780c58fa609721712b1c1e7e311','sys_file_metadata',96,'file','','','',0,0,'sys_file',15,''),
('6bad0df75a27ca814aeab90a0878db2c','sys_file_reference',105,'uid_local','','','',0,0,'sys_file',64,''),
('6be1d5ea42686a1d871a60ba96959ae6','sys_file',17,'metadata','','','',6,0,'sys_file_metadata',66,''),
('6be23a7e90b502779f8bcf5b5993f324','sys_file',17,'metadata','','','',2,0,'sys_file_metadata',43,''),
('6c03ecc0dea6d0288d40c455a9e23e40','sys_file_metadata',213,'file','','','',0,0,'sys_file',28,''),
('6c343b60060f1247e625d8046197b912','sys_file_metadata',215,'file','','','',0,0,'sys_file',30,''),
('6c52321a6fe402325e623937992bcd35','sys_file',1,'metadata','','','',10,0,'sys_file_metadata',151,''),
('6c9314708fc56fa06490467a54ba1d9d','sys_file_metadata',78,'file','','','',0,0,'sys_file',9,''),
('6d0b37bf131883292a6046b246d94a59','sys_file',45,'metadata','','','',0,0,'sys_file_metadata',230,''),
('6d25d4304db21936412e3ff162095855','sys_file_metadata',174,'file','','','',0,0,'sys_file',17,''),
('6db15e5d0a4d9ee03e5f472b0dae8cce','sys_file',15,'metadata','','','',17,0,'sys_file_metadata',176,''),
('6de7fbfdf87cd90b8d512692ad834533','sys_file',26,'storage','','','',0,0,'sys_file_storage',1,''),
('6e10dae1b9cbff416e1298204b7a17a9','sys_file_metadata',15,'file','','','',0,0,'sys_file',15,''),
('6ec47e8652cada521dc238d1ca0c87fa','sys_file',15,'metadata','','','',18,0,'sys_file_metadata',189,''),
('6f5e7b15a92ee078ca12c8af57a793b5','sys_file',9,'metadata','','','',11,0,'sys_file_metadata',116,''),
('709c1002d66763fb04aab30f7e0751ab','sys_file',15,'metadata','','','',1,0,'sys_file_metadata',28,''),
('70e16c654e919713bd51a0ae48fed608','sys_file_metadata',148,'file','','','',0,0,'sys_file',4,''),
('70fc00ba195b52ab59a3f1d9c4da8b79','sys_file',2,'metadata','','','',9,0,'sys_file_metadata',133,''),
('71134b22c15a5b1d6e50a09c78c1812a','sys_file_metadata',191,'file','','','',0,0,'sys_file',8,''),
('71885f231631e39b155d14fac1b50305','sys_file',11,'storage','','','',0,0,'sys_file_storage',1,''),
('71af3a1192b8c3038fe649a3e8739aa4','sys_file',1,'metadata','','','',3,0,'sys_file_metadata',49,''),
('7243265af91885e74bbd8d155fd8d974','sys_file_metadata',104,'file','','','',0,0,'sys_file',17,''),
('728762e1976f02adf8d243d887dbdf3d','sys_file',6,'metadata','','','',3,0,'sys_file_metadata',54,''),
('72d64c74eb830c7295ec5c6396e38970','sys_file_metadata',168,'file','','','',0,0,'sys_file',1,''),
('734ea7a3eea22286d241a8d3a50a543d','sys_file',56,'metadata','','','',0,0,'sys_file_metadata',241,''),
('73a25144306666e8c41496c1bd1240d5','sys_file_metadata',194,'file','','','',0,0,'sys_file',5,''),
('73a4ad6c86e15226ae62976172244f26','sys_file',14,'storage','','','',0,0,'sys_file_storage',1,''),
('73e71072e6adf5a1d2b643d59007c624','sys_file',17,'metadata','','','',14,0,'sys_file_metadata',140,''),
('7481e8280eaba1106394a09a54d34a88','sys_file_metadata',48,'file','','','',0,0,'sys_file',18,''),
('749b0771828793d3e3eba1372852a7a8','sys_file',2,'metadata','','','',0,0,'sys_file_metadata',2,''),
('74cdac16b4f048011d18e8279b0e9b70','sys_file_metadata',41,'file','','','',0,0,'sys_file',15,''),
('74dfdce589de625b79ddada8e5dd092f','sys_file',32,'metadata','','','',0,0,'sys_file_metadata',217,''),
('7522fc0217031429d17920232b22c08b','sys_file_metadata',9,'file','','','',0,0,'sys_file',9,''),
('754636d84d330afb42e0702d8d973600','sys_file_metadata',84,'file','','','',0,0,'sys_file',5,''),
('75aae0dbc68c8588700a91db0b603516','sys_file_metadata',23,'file','','','',0,0,'sys_file',5,''),
('75f86dd08ae015e1c006223f7d31dc9e','sys_file_metadata',180,'file','','','',0,0,'sys_file',6,''),
('761ab1cfdcb5e7cd0ed04e8a93c1e412','sys_file_metadata',39,'file','','','',0,0,'sys_file',8,''),
('767944a4a2b4c02779103739c1a89c2a','sys_file',20,'metadata','','','',0,0,'sys_file_metadata',205,''),
('76adadfd69f8a1e1b95e64a102427488','sys_file_metadata',165,'file','','','',0,0,'sys_file',4,''),
('77286f1fbbe9c5f099d5dec71c3a2287','sys_file',9,'metadata','','','',15,0,'sys_file_metadata',156,''),
('787dc91b7a5752292adc8a812751734d','sys_file_metadata',198,'file','','','',0,0,'sys_file',1,''),
('78d926000af3c5762de3436d8871f21f','sys_file_metadata',172,'file','','','',0,0,'sys_file',15,''),
('78e34716c0c41445a151dea1734eeab6','sys_file',2,'metadata','','','',6,0,'sys_file_metadata',101,''),
('791d3f9d43dcbfa78cd49dd8258caa09','sys_file',5,'storage','','','',0,0,'sys_file_storage',1,''),
('79ed2f6b662106d6f8f1163d8fb560cc','sys_file',37,'metadata','','','',0,0,'sys_file_metadata',222,''),
('79f5114fe62f1099dd3af56c699bea33','sys_file',18,'metadata','','','',2,0,'sys_file_metadata',48,''),
('7a65179d00b99129152b19a36b1ca1dc','sys_file',55,'metadata','','','',0,0,'sys_file_metadata',240,''),
('7a9456cdddb98bb377cf0bc5f997b88c','sys_file',3,'metadata','','','',3,0,'sys_file_metadata',51,''),
('7b9c4cc52bc826df6901a7363974e623','sys_file_metadata',102,'file','','','',0,0,'sys_file',8,''),
('7c5e60eedcb9a841b8c71e980c93dbd1','sys_file',17,'metadata','','','',5,0,'sys_file_metadata',64,''),
('7c67e7fdb18f3efa179016fe89911386','sys_file_metadata',230,'file','','','',0,0,'sys_file',45,''),
('7d69c4eb48d0b82a5d524b7e714c98bf','sys_file_metadata',239,'file','','','',0,0,'sys_file',54,''),
('7d82dae24108df673a374c8f1883d980','sys_file_metadata',11,'file','','','',0,0,'sys_file',11,''),
('7ee96b3c5c331042e62963859d6b942e','tt_content',83,'image','','','',0,0,'sys_file_reference',106,''),
('7fed8286d631ff81a20a385af156c722','sys_file',63,'metadata','','','',0,0,'sys_file_metadata',248,''),
('8064f0cd6d4428e6408477be08fe708f','sys_file_metadata',82,'file','','','',0,0,'sys_file',18,''),
('80d458c638ee9dac3b51f27eaaacc8d6','sys_file_metadata',108,'file','','','',0,0,'sys_file',18,''),
('80e1cde45d6702e059d1f5bbcb568921','sys_file',2,'metadata','','','',3,0,'sys_file_metadata',50,''),
('811b32b1feb41666cbc1dbd2efcb5fd6','sys_file_metadata',205,'file','','','',0,0,'sys_file',20,''),
('81264c047ab20f389ba8a4922d785994','sys_file_metadata',244,'file','','','',0,0,'sys_file',59,''),
('82128ffeaff29c5854e3edfd4374b2e9','sys_file_metadata',56,'file','','','',0,0,'sys_file',8,''),
('82b54f58a09ff7c754eb47c874eff6c2','sys_file_metadata',10,'file','','','',0,0,'sys_file',10,''),
('82daee95efc61a661f153316f0eea055','sys_file',15,'metadata','','','',10,0,'sys_file_metadata',115,''),
('82e34367cafc45231b2763729d47565b','sys_file_metadata',129,'file','','','',0,0,'sys_file',6,''),
('83d27ef4fc468b74c7dfb596a78517c7','sys_file',17,'metadata','','','',11,0,'sys_file_metadata',113,''),
('83e3b7104c7492b2407ecfbe19405fc5','sys_file_metadata',127,'file','','','',0,0,'sys_file',8,''),
('83e547bebf151c6d932f7bdc5487ef64','sys_file',9,'storage','','','',0,0,'sys_file_storage',1,''),
('849ac0a0450ea0071697245aefcfcd8a','sys_file_metadata',231,'file','','','',0,0,'sys_file',46,''),
('8542033c484dfc7a95b89eda597fe297','sys_file_metadata',45,'file','','','',0,0,'sys_file',15,''),
('863b83c987c5aa95209eaedbbcd2078c','sys_file',4,'metadata','','','',10,0,'sys_file_metadata',195,''),
('8803721cfdc3bf14337fb31b24bdfe5d','sys_file_metadata',185,'file','','','',0,0,'sys_file',1,''),
('8848abfb4975cd1fd64cf24937a5cbbc','sys_file_metadata',74,'file','','','',0,0,'sys_file',5,''),
('8936f439c57a66948c11204ad7f6bf61','sys_file_metadata',236,'file','','','',0,0,'sys_file',51,''),
('8986973777587d0a1a4616bccc71d0c6','sys_file_metadata',87,'file','','','',0,0,'sys_file',1,''),
('8987893411baca05f986dca0a4c38bd8','sys_file',5,'metadata','','','',0,0,'sys_file_metadata',5,''),
('89a994e22d9fba7b3b6a0a875dd20909','sys_file_metadata',72,'file','','','',0,0,'sys_file',3,''),
('89dd16cd18859b86b0127b989d856e24','sys_file',5,'metadata','','','',6,0,'sys_file_metadata',130,''),
('89e8a477bb1f955818cedc21d545526e','sys_file',1,'metadata','','','',7,0,'sys_file_metadata',107,''),
('8a831ec7aa7c7d3064ce9876d1a8e8b4','sys_file',65,'metadata','','','',0,0,'sys_file_metadata',250,''),
('8bbdf049467329043973787338db96e4','sys_file_metadata',235,'file','','','',0,0,'sys_file',50,''),
('8bc2e209c59a727f009f7a10c6dffddf','sys_file',3,'metadata','','','',7,0,'sys_file_metadata',121,''),
('8c2bddac459f3fa08e5b0980f4ba0bbe','sys_file_metadata',27,'file','','','',0,0,'sys_file',9,''),
('8c3bd44e2c75808ff15b1d93b72716e2','sys_file_metadata',187,'file','','','',0,0,'sys_file',17,''),
('8cd40f299cfd364f01d5451425f3c3a3','sys_file_metadata',126,'file','','','',0,0,'sys_file',9,''),
('8cecd7a8d95fcd51efde7537e006c745','sys_file',51,'metadata','','','',0,0,'sys_file_metadata',236,''),
('8d23731a2b2037f4781f89c5149c57be','sys_file_metadata',5,'file','','','',0,0,'sys_file',5,''),
('8d53ce2a89126b0ed5c80a0141c4f613','sys_file_metadata',32,'file','','','',0,0,'sys_file',1,''),
('8ea5c70727137631a733aa5d46262a64','sys_file',9,'metadata','','','',9,0,'sys_file_metadata',103,''),
('8f2a17305df5c5ab450f4aba6639796c','sys_file',15,'metadata','','','',13,0,'sys_file_metadata',142,''),
('9023f14e02db15ed98a9daf3db049f1f','sys_file_metadata',110,'file','','','',0,0,'sys_file',8,''),
('9089b186969d90ecc6b7fb76a973450e','sys_file',3,'metadata','','','',8,0,'sys_file_metadata',132,''),
('91ab5f43df0209fc13dd69f1452b491a','sys_file_metadata',229,'file','','','',0,0,'sys_file',44,''),
('91eee7a4d323da8bae720a1da4a1f2de','sys_file',65,'storage','','','',0,0,'sys_file_storage',1,''),
('92a59cdbdd28ebf66734a450ff79f1c2','sys_file',6,'metadata','','','',2,0,'sys_file_metadata',37,''),
('938352f157b8c003d15f693b671238aa','sys_file_metadata',200,'file','','','',0,0,'sys_file',13,''),
('93ad9f2d1e59582168b64275beaf01b5','tt_content',84,'bodytext','','typolink_tag','1',-1,0,'pages',47,''),
('93b919dcdeed610654d5b201e9cfe906','sys_file',64,'storage','','','',0,0,'sys_file_storage',1,''),
('94622f5d993f34c59d4b386797d07453','sys_file_metadata',226,'file','','','',0,0,'sys_file',41,''),
('94b9babd4ccf9a972f7f2d1d39ab3e35','sys_file_metadata',130,'file','','','',0,0,'sys_file',5,''),
('9538efb8cd81edd846380878b5e31b1d','sys_file',30,'metadata','','','',0,0,'sys_file_metadata',215,''),
('9559adaef6ce52de23c85dab85e75630','sys_file_metadata',20,'file','','','',0,0,'sys_file',2,''),
('95f8d1fba628744f3f7c06516ad8bffb','sys_file_metadata',219,'file','','','',0,0,'sys_file',34,''),
('966984ab7641e363e0ba71dbaf80af97','sys_file',9,'metadata','','','',3,0,'sys_file_metadata',44,''),
('97a9976b002a19fe51854a3e4e33fc74','sys_file',15,'metadata','','','',9,0,'sys_file_metadata',96,''),
('984edba9beda7d39066eaeaf56564522','sys_file',47,'metadata','','','',0,0,'sys_file_metadata',232,''),
('98bfd1b575ae6ed10a57e5c5c8e5a38c','sys_file',27,'metadata','','','',0,0,'sys_file_metadata',212,''),
('99991782a21a378d0c680779f69cca5a','sys_file',5,'metadata','','','',8,0,'sys_file_metadata',164,''),
('99de689fcc8d549c1edc8d615d5e37a0','sys_file_metadata',4,'file','','','',0,0,'sys_file',4,''),
('9a5fc2b6b24022fbcc3061c88bca200f','sys_file_metadata',40,'file','','','',0,0,'sys_file',9,''),
('9b2cf11bd59e6ff904ea2e8b86178727','sys_file_metadata',132,'file','','','',0,0,'sys_file',3,''),
('9b6780381d2f20f4e7104bf5a0b0443c','sys_file_metadata',92,'file','','','',0,0,'sys_file',15,''),
('9bb03b5b6e8435697a097a3347e6be63','sys_file',43,'storage','','','',0,0,'sys_file_storage',1,''),
('9bda2102a45d9b1b5385ff283087b87c','sys_file',15,'metadata','','','',3,0,'sys_file_metadata',45,''),
('9bef7c995a48a1fcc5a45e51ecb34f2c','sys_file',5,'metadata','','','',2,0,'sys_file_metadata',36,''),
('9c2b161c37eca1c4d4bac8df60b5b77d','sys_file_metadata',66,'file','','','',0,0,'sys_file',17,''),
('9c9df87c0c161aebc90355911d801652','sys_file_metadata',247,'file','','','',0,0,'sys_file',62,''),
('9c9e58c380e7831ef499f41f99b93877','sys_file_metadata',123,'file','','','',0,0,'sys_file',17,''),
('9cb234956102ad2951c680d0a3d87a97','sys_file',9,'metadata','','','',14,0,'sys_file_metadata',143,''),
('9cc3f820ab6a69459a9c2fc66a61f092','sys_file',6,'metadata','','','',0,0,'sys_file_metadata',6,''),
('9d166febe6a7317118f8c38e7b11a521','sys_file_metadata',91,'file','','','',0,0,'sys_file',9,''),
('9d3b75034f72b0cabc25dd9fbbcd43ed','sys_file',5,'metadata','','','',1,0,'sys_file_metadata',23,''),
('9ed9912f896b0a81616cdd7c5a3fd224','sys_file',52,'metadata','','','',0,0,'sys_file_metadata',237,''),
('9f99353c84eac3be593b6f8cb68404d3','sys_file',44,'storage','','','',0,0,'sys_file_storage',1,''),
('a0c794863e332236dabf807a24457a8d','sys_file',4,'metadata','','','',2,0,'sys_file_metadata',35,''),
('a1c48e41f2d82a41b5820011b0782793','sys_file',57,'metadata','','','',0,0,'sys_file_metadata',242,''),
('a20d503e595ccceb441b760481070346','sys_file',15,'metadata','','','',14,0,'sys_file_metadata',155,''),
('a277e1e8f4b297829874670c5bfb5fad','sys_file',6,'metadata','','','',5,0,'sys_file_metadata',85,''),
('a31355f4172f0285ea02f695ee2532f4','sys_file_metadata',176,'file','','','',0,0,'sys_file',15,''),
('a3520b29181a0ae5ba377bad52cdacd7','sys_file_metadata',21,'file','','','',0,0,'sys_file',3,''),
('a38a7a2242c03f982f1c4424556120a3','sys_file_metadata',161,'file','','','',0,0,'sys_file',8,''),
('a406c1f1adaa486aa78a1fcfb56406ba','sys_file_metadata',245,'file','','','',0,0,'sys_file',60,''),
('a40d00ebcf8c8e4d7610e4953933d44c','sys_file',9,'metadata','','','',1,0,'sys_file_metadata',27,''),
('a40dda34312f2bfe02624c719673620a','sys_file',9,'metadata','','','',8,0,'sys_file_metadata',91,''),
('a4ce1010ac7950104f7cddfcad95e503','sys_file',63,'storage','','','',0,0,'sys_file_storage',1,''),
('a56586b3d2ab2d1e6a9bbb1ac4678494','sys_file_metadata',223,'file','','','',0,0,'sys_file',40,''),
('a592748dd40f8b437ff057dd9a873e65','sys_file',37,'storage','','','',0,0,'sys_file_storage',1,''),
('a5e9ec91263cc0edd756320b67c91bcc','sys_file',49,'metadata','','','',0,0,'sys_file_metadata',234,''),
('a6d2da89e82066e99b7c57d213b5a152','sys_file',60,'metadata','','','',0,0,'sys_file_metadata',245,''),
('a757be8d241fb6eeff1170a1e3c85a18','sys_file_metadata',100,'file','','','',0,0,'sys_file',1,''),
('a77b17fae03223efa10d1398e3b53fe9','sys_file',3,'metadata','','','',6,0,'sys_file_metadata',97,''),
('a78695aece105fe1b61a490390ab3b33','sys_file',8,'metadata','','','',9,0,'sys_file_metadata',127,''),
('a87344067faefa9fb880a404a4790d94','sys_file',9,'metadata','','','',0,0,'sys_file_metadata',9,''),
('a8de8bee142aed985ba7e1e2c9069ae5','sys_file',1,'metadata','','','',6,0,'sys_file_metadata',100,''),
('a8fb2e8b9734b34b2466e289ba00547d','sys_file',62,'metadata','','','',0,0,'sys_file_metadata',247,''),
('aad03854ab1e1aa889fded4d2b40f9f3','sys_file',18,'metadata','','','',12,0,'sys_file_metadata',169,''),
('aadb2c2912429d9fcee5801d33956b23','sys_file_metadata',105,'file','','','',0,0,'sys_file',18,''),
('ab3f575be7c5c84cbd65c92b49cdf5c3','sys_file',15,'metadata','','','',4,0,'sys_file_metadata',58,''),
('ab8655c06222bd54343d13a848f4ea39','sys_file',48,'metadata','','','',0,0,'sys_file_metadata',233,''),
('abad25831358dd8df9bf9d892160ad1a','sys_file_metadata',44,'file','','','',0,0,'sys_file',9,''),
('acad7de8bdd8e48a4485aafaa3fa0488','sys_file_metadata',146,'file','','','',0,0,'sys_file',6,''),
('ad59e29944adc9153845e6d2bf091473','sys_file_metadata',206,'file','','','',0,0,'sys_file',21,''),
('ad6b63209c24e1259b68dd2c8ca8aca2','sys_file_metadata',19,'file','','','',0,0,'sys_file',1,''),
('adff59518c68b7c6e4dca65245b57aed','sys_file_metadata',3,'file','','','',0,0,'sys_file',3,''),
('ae1601700425b8698c65bffb4d9f1fba','sys_file_reference',107,'uid_local','','','',0,0,'sys_file',64,''),
('ae6fedbfbf7ca48f4964d84684726ca6','sys_file',15,'metadata','','','',16,0,'sys_file_metadata',172,''),
('aeaf26e9144edf8b08c6f9dc9257a4e2','sys_file_metadata',196,'file','','','',0,0,'sys_file',3,''),
('af015e3f86ca87230044dbce5ad7a436','sys_file_metadata',85,'file','','','',0,0,'sys_file',6,''),
('af4e76b459279eea6488c34ad608e43c','sys_file',9,'metadata','','','',10,0,'sys_file_metadata',111,''),
('b00a34d21f9c737304acd664212979d2','sys_file_metadata',152,'file','','','',0,0,'sys_file',18,''),
('b00afd93025c95cab63e35f8f3566da9','sys_file_metadata',142,'file','','','',0,0,'sys_file',15,''),
('b04da32e814ec05cbb7c8ac180d51e33','sys_file_metadata',201,'file','','','',0,0,'sys_file',12,''),
('b104d7892d4ae73f634736b09095853b','sys_file',2,'metadata','','','',8,0,'sys_file_metadata',119,''),
('b1d4b99e7e66eb282457d86ac7aa6ab1','sys_file_metadata',241,'file','','','',0,0,'sys_file',56,''),
('b3a3c1864824639c442ebba52d9f97b6','sys_file_metadata',86,'file','','','',0,0,'sys_file',3,''),
('b4732d11e154dcc49d640ed80ccb83cc','sys_file_metadata',112,'file','','','',0,0,'sys_file',18,''),
('b499472314552b9040285852463a74ea','sys_file',28,'metadata','','','',0,0,'sys_file_metadata',213,''),
('b4aa84704e258b74627c309cad50401b','sys_file_metadata',147,'file','','','',0,0,'sys_file',5,''),
('b51775019ab8d6ed560d47b7e8b6b789','sys_file_metadata',216,'file','','','',0,0,'sys_file',31,''),
('b52dc94fe74cf0fea17308b023de9abd','sys_file',6,'metadata','','','',1,0,'sys_file_metadata',24,''),
('b5592850575ad40dec833531e34a6c8f','sys_file_metadata',149,'file','','','',0,0,'sys_file',3,''),
('b595e72f0a3dea8fe49bfd27952b24a8','sys_file_metadata',207,'file','','','',0,0,'sys_file',22,''),
('b5a2dd864e8f24cc14eb9bbcf0b4015f','sys_file_metadata',204,'file','','','',0,0,'sys_file',19,''),
('b5aac7f77aaf2159dce2186e14f9b650','sys_file_metadata',199,'file','','','',0,0,'sys_file',14,''),
('b62a068c0c8a17d3f73e5c5f009bb16e','sys_file',10,'metadata','','','',1,0,'sys_file_metadata',203,''),
('b655b7858569411ca054fcdfcf70fb32','sys_file',14,'metadata','','','',1,0,'sys_file_metadata',199,''),
('b776d20158f3c8b7c504365377ae93fd','sys_file_metadata',81,'file','','','',0,0,'sys_file',17,''),
('b79e6bb89d0c0b351168e8255ae6f358','sys_file',9,'metadata','','','',12,0,'sys_file_metadata',126,''),
('b7e727aff895474fb34059039c44c0d3','sys_file_reference',104,'uid_local','','','',0,0,'sys_file',63,''),
('b89c8ede27a908b099f2cb15ae1d8836','sys_file_metadata',135,'file','','','',0,0,'sys_file',18,''),
('b950281f5b8cdf205d18bffced93fd99','sys_file_metadata',79,'file','','','',0,0,'sys_file',15,''),
('ba532be19a66ea973bba920281080b7a','sys_file_metadata',61,'file','','','',0,0,'sys_file',9,''),
('ba8ec115beb88856361291bf87ff7c6d','sys_file_metadata',6,'file','','','',0,0,'sys_file',6,''),
('baa22019f2ea8b1f88ed6ba714399740','sys_file_metadata',13,'file','','','',0,0,'sys_file',13,''),
('bab37143de5339e474516691bf0c5857','sys_file',4,'storage','','','',0,0,'sys_file_storage',1,''),
('bb08bce1c06acbb9e8e85377f800354d','sys_file',3,'metadata','','','',11,0,'sys_file_metadata',183,''),
('bb50f5cdc6068dc39cced256878641de','sys_file_metadata',64,'file','','','',0,0,'sys_file',17,''),
('bb9038a252bcfeadc2e1e8a6b5266986','sys_file_metadata',1,'file','','','',0,0,'sys_file',1,''),
('bbfc8689f113ad1cd69b1603a05e53b6','sys_file_metadata',203,'file','','','',0,0,'sys_file',10,''),
('bbfe4da2230fc97caea66ebd7234a0d7','sys_file',17,'metadata','','','',10,0,'sys_file_metadata',109,''),
('bc942c9f52ae25a81b80b646b2dc4605','sys_file_metadata',209,'file','','','',0,0,'sys_file',24,''),
('bcef79145bcb10080a8c2a58fc6f9229','sys_file',9,'metadata','','','',19,0,'sys_file_metadata',190,''),
('bceff0b2a30e8d3b4b10618fca2dbf24','sys_file',15,'metadata','','','',6,0,'sys_file_metadata',68,''),
('bd463e13accf2f5008e4020e5137193b','sys_file',17,'metadata','','','',1,0,'sys_file_metadata',30,''),
('bd7fd9033b28b622387589e90afcc88f','sys_file_metadata',250,'file','','','',0,0,'sys_file',65,''),
('bd944f488734827d7b59d86435409808','sys_file_metadata',238,'file','','','',0,0,'sys_file',53,''),
('be23a584422ca0ae4e8fb43e42439866','sys_file',17,'metadata','','','',16,0,'sys_file_metadata',157,''),
('c1926fab4363c83bb1de1712150cbb82','sys_file_metadata',36,'file','','','',0,0,'sys_file',5,''),
('c195685f0ed52a2cc01f46b44f5d1adb','sys_file',18,'metadata','','','',1,0,'sys_file_metadata',31,''),
('c324078642f8db69d2d6af1b23012c46','sys_file',5,'metadata','','','',10,0,'sys_file_metadata',194,''),
('c47450bae3b35c6c014d47f96dbc86dc','sys_file_metadata',116,'file','','','',0,0,'sys_file',9,''),
('c4b776312ab9b28dc427c817cdbd20f4','sys_file_metadata',225,'file','','','',0,0,'sys_file',39,''),
('c4c4ba60721eb0a7a35016ec6a62cc9a','sys_file_metadata',18,'file','','','',0,0,'sys_file',18,''),
('c644c0d5eb64cb296caf7a23573f9613','sys_file_metadata',208,'file','','','',0,0,'sys_file',23,''),
('c835b3f13d9643733236c3aa418bab36','sys_file',33,'metadata','','','',0,0,'sys_file_metadata',218,''),
('c8c087cddc1d41e4bfcefbe13cf6dc98','sys_file',2,'metadata','','','',13,0,'sys_file_metadata',197,''),
('c8ca72afb7d1d934d290aa66c01f853a','sys_file',58,'metadata','','','',0,0,'sys_file_metadata',243,''),
('c905d0b89df34069267a3a925951d1ce','sys_file_metadata',243,'file','','','',0,0,'sys_file',58,''),
('ca42a4117365d54c5e9b68bd56b84f4b','sys_file_metadata',202,'file','','','',0,0,'sys_file',11,''),
('ca564e2ebefe5894bf5db4a05f3cc0bc','sys_file_metadata',237,'file','','','',0,0,'sys_file',52,''),
('cb7fc531bad56900b5cbd383b2548f20','sys_file',9,'metadata','','','',6,0,'sys_file_metadata',69,''),
('ccd39a77d50c54a2c4b72ac15697927a','sys_file_metadata',117,'file','','','',0,0,'sys_file',8,''),
('cd843b64c82146b4edb533e2fd311524','sys_file_metadata',211,'file','','','',0,0,'sys_file',26,''),
('cde765558cfa674e87ef0a6ee7fb7407','sys_file',18,'metadata','','','',11,0,'sys_file_metadata',152,''),
('cdfa7dd5b8e489ff5a7b2de3e7444014','tt_content',78,'image','','','',0,0,'sys_file_reference',104,''),
('ce1ea0986b360b95674fd28a6f62548e','sys_file_metadata',22,'file','','','',0,0,'sys_file',4,''),
('ce40accc4f9adf726448b130d03518f7','sys_file',1,'metadata','','','',2,0,'sys_file_metadata',32,''),
('ce50b3d427c392a397e5518cb56159bc','sys_file',8,'metadata','','','',2,0,'sys_file_metadata',39,''),
('ce8ad2263711e5b471d4499e50556c49','sys_file_metadata',178,'file','','','',0,0,'sys_file',8,''),
('cf817a6919cb34dafa23ab4c165de3f9','sys_file',1,'metadata','','','',5,0,'sys_file_metadata',87,''),
('cff0de708d7303bd0c89c630487d84f6','sys_file_metadata',167,'file','','','',0,0,'sys_file',2,''),
('d00c4597625da6a0c0a00e65e0004d8a','sys_file',17,'metadata','','','',3,0,'sys_file_metadata',47,''),
('d084c4e75857300a6993cae4e85af808','sys_file_metadata',107,'file','','','',0,0,'sys_file',1,''),
('d221b72a9b833ec3ea012a82512e1663','sys_file_metadata',68,'file','','','',0,0,'sys_file',15,''),
('d227a77ae57d974402b2eef7528fa11b','sys_file',3,'metadata','','','',12,0,'sys_file_metadata',196,''),
('d2946c4af2ee1975f136529f974c5af5','sys_file',17,'metadata','','','',4,0,'sys_file_metadata',60,''),
('d3113a9aa4b546a2b8450b6b079a88bd','sys_file_metadata',184,'file','','','',0,0,'sys_file',2,''),
('d3a128b4f6e35e9a07c079cc8d84bc4c','sys_file_metadata',193,'file','','','',0,0,'sys_file',6,''),
('d3fdc49097a86696af0e54f230566005','sys_file_metadata',228,'file','','','',0,0,'sys_file',43,''),
('d48024d2d507d1c20444a7b6abf7fcd4','sys_file_metadata',57,'file','','','',0,0,'sys_file',9,''),
('d54c432be863ca593a90b4e857359ca8','sys_file',44,'metadata','','','',0,0,'sys_file_metadata',229,''),
('d5a4fa1943872b8d1cd016050c9995b8','sys_file_metadata',17,'file','','','',0,0,'sys_file',17,''),
('d6916926456f4627042d41734e4a2702','sys_file',4,'metadata','','','',1,0,'sys_file_metadata',22,''),
('d6b3289c6a4a4b23431b31c359915cb3','sys_file',3,'metadata','','','',9,0,'sys_file_metadata',149,''),
('d6b8a1a1759cdfaf9379b3c469817937','sys_file',8,'metadata','','','',4,0,'sys_file_metadata',77,''),
('d7a7760d04e935dbbbbd19da0ab0e09c','sys_file_metadata',37,'file','','','',0,0,'sys_file',6,''),
('d7b9d9c44e64e4b19f23d8febc9ecec4','sys_file_metadata',106,'file','','','',0,0,'sys_file',2,''),
('d819174f473bbedad3046f608d1e7c63','sys_file_metadata',182,'file','','','',0,0,'sys_file',4,''),
('d820b955e57a74409d96d7a93f9f77dd','sys_file_metadata',134,'file','','','',0,0,'sys_file',1,''),
('d88b2feac140cc4fa82e221f2d196233','sys_file',12,'metadata','','','',0,0,'sys_file_metadata',12,''),
('d8f57394dd958575a3a08f5bdf8270aa','sys_file',6,'metadata','','','',10,0,'sys_file_metadata',193,''),
('d9fc7e2e23d212e488a16e718a7c545a','sys_file_metadata',60,'file','','','',0,0,'sys_file',17,''),
('dae5635e90cc6bfc9d4dd6b141cc2277','sys_file_metadata',58,'file','','','',0,0,'sys_file',15,''),
('db680af6e6ec60378b343c29e77fd899','sys_file',6,'metadata','','','',8,0,'sys_file_metadata',163,''),
('db964efa3099baac04cf21037f4e3611','sys_file_metadata',183,'file','','','',0,0,'sys_file',3,''),
('dbbb5b1c091a59a3038f681db34fb093','sys_file_metadata',157,'file','','','',0,0,'sys_file',17,''),
('dc1c8eb4d955ea9d2054bb055b1e273e','sys_file_metadata',156,'file','','','',0,0,'sys_file',9,''),
('dc6bdb524d59ee1c03ff4e118a04c102','sys_file',40,'metadata','','','',0,0,'sys_file_metadata',223,''),
('dd4ed52e41297ec5e7625bf25af5625e','sys_file',8,'metadata','','','',8,0,'sys_file_metadata',117,''),
('dda4fb0f9902b4f9803e080bbfc1b6a7','sys_file',9,'metadata','','','',5,0,'sys_file_metadata',61,''),
('de17e64b0aa7937d40b82a4c5c9c66b9','sys_file',18,'metadata','','','',9,0,'sys_file_metadata',122,''),
('df1d78714866a0cff14d01f334e705f9','sys_file_metadata',31,'file','','','',0,0,'sys_file',18,''),
('df60dfd5d606f3199aa0b632b168ad70','sys_file_metadata',195,'file','','','',0,0,'sys_file',4,''),
('dfb431b6bf63fdcefe3e1456c7ed363b','sys_file',2,'metadata','','','',10,0,'sys_file_metadata',150,''),
('e0cd57f9a6597763bc20404b93c4e04d','sys_file_metadata',49,'file','','','',0,0,'sys_file',1,''),
('e198f0cd19ebf63df7e09e6a9a22ecea','sys_file_metadata',189,'file','','','',0,0,'sys_file',15,''),
('e4cd5c16f4b9fd06b94d3814563ac0b1','sys_file_metadata',26,'file','','','',0,0,'sys_file',8,''),
('e599ce3c29c12826a7c8d395e8aa9a36','sys_file',5,'metadata','','','',9,0,'sys_file_metadata',181,''),
('e60949fd5c5c3c8f422304ce33665fa6','tt_content',84,'bodytext','','typolink_tag','3',-1,0,'pages',46,''),
('e7b70b6a4c99b03e866ef3a86c84d559','sys_file_metadata',139,'file','','','',0,0,'sys_file',9,''),
('e7e46c8806056762fcfafb6d8aef5116','sys_file_metadata',62,'file','','','',0,0,'sys_file',15,''),
('e8cc4007f160189ff2cb080b174335e3','sys_file_metadata',222,'file','','','',0,0,'sys_file',37,''),
('ea475426ae309f23f1687157c31eec6c','sys_file_metadata',220,'file','','','',0,0,'sys_file',35,''),
('ea9ba2b0f0d671044b31656ace4eee60','sys_file_metadata',159,'file','','','',0,0,'sys_file',15,''),
('eb2653780c25deadd1ed253485b02dbe','sys_file',33,'storage','','','',0,0,'sys_file_storage',1,''),
('eba3edcca5617605a00d4b7a61aca7c4','sys_file',18,'storage','','','',0,0,'sys_file_storage',1,''),
('ec01e9666331703a2215b40555f23bf6','sys_file',4,'metadata','','','',0,0,'sys_file_metadata',4,''),
('eea51b25788ff482816b28befe6ae756','sys_file_metadata',144,'file','','','',0,0,'sys_file',8,''),
('eec3d4c380db663833b66248289c8a3d','sys_file',15,'metadata','','','',0,0,'sys_file_metadata',15,''),
('ef458139d74d58f79417cc08bc034a87','sys_file',2,'metadata','','','',4,0,'sys_file_metadata',71,''),
('ef5b84bc784547bdf55ed661b4471e23','sys_file',6,'metadata','','','',6,0,'sys_file_metadata',129,''),
('efe5ffbc1b341f3a5efb8f97fed82792','sys_file_metadata',8,'file','','','',0,0,'sys_file',8,''),
('eff89b8f5081a76da1ab9ca926ed538a','sys_file',42,'metadata','','','',0,0,'sys_file_metadata',227,''),
('f223326ab79d444628df0fde8eccdaf8','sys_file',2,'metadata','','','',12,0,'sys_file_metadata',184,''),
('f32a3c12853b7b58fa8c05786707daa6','sys_file_metadata',169,'file','','','',0,0,'sys_file',18,''),
('f493a87a434cf977389beffaa8fd88ab','tt_content',82,'bodytext','','typolink_tag','1',-1,0,'pages',16,''),
('f4e43f47c1b012625006c2e2bec081f8','sys_file',6,'metadata','','','',7,0,'sys_file_metadata',146,''),
('f6cb748a5f083d94e3946e2b9973f21b','sys_file',5,'metadata','','','',3,0,'sys_file_metadata',53,''),
('f7042e93deb0b500f1b8d637e7b92f15','sys_file',17,'metadata','','','',15,0,'sys_file_metadata',153,''),
('f71a6417e91cc242f3515b5c107d7873','sys_file',4,'metadata','','','',4,0,'sys_file_metadata',73,''),
('f723b298d911f54644273ffaa17563ca','sys_file',1,'metadata','','','',8,0,'sys_file_metadata',120,''),
('f7ea6d7c19a84a411589ca09356001a8','sys_file',54,'metadata','','','',0,0,'sys_file_metadata',239,''),
('f81f92b2d99d26be455cc479718d8a4f','sys_file_metadata',212,'file','','','',0,0,'sys_file',27,''),
('f97e705b337a6ef63812471e8a7ab2c1','sys_file',15,'metadata','','','',5,0,'sys_file_metadata',62,''),
('fa98b45a3c6c53d9716b0d3a05bc9c38','sys_file',17,'storage','','','',0,0,'sys_file_storage',1,''),
('fb149e2ea3ae318985101d54c3757ca8','sys_file',34,'storage','','','',0,0,'sys_file_storage',1,''),
('fb818c401ed63ce5db09897fad9d35b2','sys_file',2,'metadata','','','',11,0,'sys_file_metadata',167,''),
('fbe9cd7610da00511c03bb433b36b88c','sys_file',35,'metadata','','','',0,0,'sys_file_metadata',220,''),
('fc6334080ea642e71174625d8974fd28','sys_file',1,'metadata','','','',1,0,'sys_file_metadata',19,''),
('fd9e2fafb3b40fdd475675054aad88a3','sys_file',8,'metadata','','','',7,0,'sys_file_metadata',110,''),
('fe80a6589cac9798aa13ab5e0192cb56','sys_file',1,'metadata','','','',0,0,'sys_file_metadata',1,''),
('feda06a0484a4a79fd0a847b01d21291','sys_file',15,'metadata','','','',15,0,'sys_file_metadata',159,''),
('fee4648174e04d547d10edfe9c66c1d7','sys_file_metadata',153,'file','','','',0,0,'sys_file',17,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FeeditExtractionUpdate','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\TaskcenterExtractionUpdate','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysActionExtractionUpdate','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SvgFilesSanitization','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\ShortcutRecordsMigration','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\CollectionsExtractionUpdate','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserLanguageMigration','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogChannel','i:1;'),
(9,'installUpdate','TYPO3\\CMS\\FrontendLogin\\Updates\\MigrateFeloginPlugins','i:1;'),
(10,'installUpdateRows','rowUpdatersDone','a:5:{i:0;s:69:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceVersionRecordsMigration\";i:1;s:66:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\L18nDiffsourceToJsonMigration\";i:2;s:77:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceMovePlaceholderRemovalMigration\";i:3;s:76:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceNewPlaceholderRemovalMigration\";i:4;s:69:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\SysRedirectRootPageMoveMigration\";}'),
(11,'extensionDataImport','typo3/sysext/core/ext_tables_static+adt.sql','s:0:\"\";'),
(12,'extensionDataImport','typo3/sysext/scheduler/ext_tables_static+adt.sql','s:0:\"\";'),
(13,'extensionDataImport','typo3/sysext/extbase/ext_tables_static+adt.sql','s:0:\"\";'),
(14,'extensionDataImport','typo3/sysext/fluid/ext_tables_static+adt.sql','s:0:\"\";'),
(15,'extensionDataImport','typo3/sysext/install/ext_tables_static+adt.sql','s:0:\"\";'),
(16,'extensionDataImport','typo3/sysext/recordlist/ext_tables_static+adt.sql','s:0:\"\";'),
(17,'extensionDataImport','typo3/sysext/backend/ext_tables_static+adt.sql','s:0:\"\";'),
(18,'extensionDataImport','typo3/sysext/frontend/ext_tables_static+adt.sql','s:0:\"\";'),
(19,'extensionDataImport','typo3/sysext/adminpanel/ext_tables_static+adt.sql','s:0:\"\";'),
(20,'extensionDataImport','typo3/sysext/dashboard/ext_tables_static+adt.sql','s:0:\"\";'),
(21,'extensionDataImport','typo3/sysext/reports/ext_tables_static+adt.sql','s:0:\"\";'),
(22,'extensionDataImport','typo3/sysext/redirects/ext_tables_static+adt.sql','s:0:\"\";'),
(23,'extensionDataImport','typo3/sysext/fluid_styled_content/ext_tables_static+adt.sql','s:0:\"\";'),
(24,'extensionDataImport','typo3/sysext/filelist/ext_tables_static+adt.sql','s:0:\"\";'),
(25,'extensionDataImport','typo3/sysext/impexp/ext_tables_static+adt.sql','s:0:\"\";'),
(26,'extensionDataImport','typo3/sysext/form/ext_tables_static+adt.sql','s:0:\"\";'),
(27,'extensionDataImport','typo3/sysext/info/ext_tables_static+adt.sql','s:0:\"\";'),
(28,'extensionDataImport','typo3/sysext/linkvalidator/ext_tables_static+adt.sql','s:0:\"\";'),
(29,'extensionDataImport','typo3/sysext/seo/ext_tables_static+adt.sql','s:0:\"\";'),
(30,'extensionDataImport','typo3/sysext/setup/ext_tables_static+adt.sql','s:0:\"\";'),
(31,'extensionDataImport','typo3/sysext/rte_ckeditor/ext_tables_static+adt.sql','s:0:\"\";'),
(32,'extensionDataImport','typo3/sysext/belog/ext_tables_static+adt.sql','s:0:\"\";'),
(33,'extensionDataImport','typo3/sysext/beuser/ext_tables_static+adt.sql','s:0:\"\";'),
(34,'extensionDataImport','typo3/sysext/extensionmanager/ext_tables_static+adt.sql','s:0:\"\";'),
(35,'extensionDataImport','typo3/sysext/felogin/ext_tables_static+adt.sql','s:0:\"\";'),
(36,'extensionDataImport','typo3/sysext/filemetadata/ext_tables_static+adt.sql','s:0:\"\";'),
(37,'extensionDataImport','typo3/sysext/lowlevel/ext_tables_static+adt.sql','s:0:\"\";'),
(38,'extensionDataImport','typo3/sysext/sys_note/ext_tables_static+adt.sql','s:0:\"\";'),
(39,'extensionDataImport','typo3/sysext/t3editor/ext_tables_static+adt.sql','s:0:\"\";'),
(40,'extensionDataImport','typo3/sysext/tstemplate/ext_tables_static+adt.sql','s:0:\"\";'),
(41,'extensionDataImport','typo3/sysext/viewpage/ext_tables_static+adt.sql','s:0:\"\";'),
(42,'extensionDataImport','typo3conf/ext/buffpackage_contentelements/ext_tables_static+adt.sql','s:0:\"\";'),
(43,'extensionDataImport','typo3conf/ext/buffpackage/ext_tables_static+adt.sql','s:0:\"\";'),
(44,'extensionDataImport','typo3conf/ext/buffpackage/Initialisation/dataImported','i:1;'),
(45,'extensionDataImport','typo3conf/ext/content_defender/ext_tables_static+adt.sql','s:0:\"\";'),
(46,'extensionDataImport','helhum/typo3-console/ext_tables_static+adt.sql','s:0:\"\";'),
(47,'extensionDataImport','typo3conf/ext/ig_slug/ext_tables_static+adt.sql','s:0:\"\";'),
(48,'extensionDataImport','typo3conf/ext/webp/ext_tables_static+adt.sql','s:0:\"\";'),
(49,'extensionDataImport','les_static+adt.sql','s:0:\"\";'),
(50,'languagePacks','de-buffpackage','i:1705911202;'),
(51,'languagePacks','de-buffpackage_contentelements','i:1683117013;'),
(52,'languagePacks','de-ig_slug','i:1705911204;'),
(53,'languagePacks','de','i:1705911207;'),
(55,'tx_reports','status.highestSeverity','i:1;'),
(56,'core','formProtectionSessionToken:3','s:64:\"4a9948a336d6f7de21bcc32cd1b238dd7cc1acf5bb35242300f026b19ebd74f7\";'),
(58,'languagePacks','de-translate_locallang','i:1705911207;'),
(59,'core','sys_refindex_lastUpdate','i:1715095647;'),
(60,'core','formProtectionSessionToken:2','s:64:\"a4d374bc434531a6bdbfb59389d60e55c2817a14da2eb97e5e3e851332dfafba\";'),
(62,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PasswordPolicyForFrontendUsersUpdate','i:1;'),
(64,'core','formProtectionSessionToken:1','s:64:\"2975b9da8afae1e6aee6ddc8883092cdf1084e55b34ce5d20556f07dfad2ef71\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` text DEFAULT NULL,
  `constants` text DEFAULT NULL,
  `config` text DEFAULT NULL,
  `basedOn` tinytext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES
(1,1,1715023899,1669973002,0,0,0,0,256,NULL,0,'TYPO3 Functional Colors',1,3,'','@import \'EXT:typo3_functional_colors/Configuration/TypoScript/constants.typoscript\'','@import \'EXT:typo3_functional_colors/Configuration/TypoScript/setup.typoscript\'','',0,0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text DEFAULT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT '',
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `bodytext` mediumtext DEFAULT NULL,
  `bullets_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `records` text DEFAULT NULL,
  `pages` text DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `header_link` varchar(1024) NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` varchar(30) NOT NULL DEFAULT '0',
  `list_type` varchar(255) NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 0,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` text DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `date` int(11) NOT NULL DEFAULT 0,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` mediumtext DEFAULT NULL,
  `accessibility_title` varchar(30) NOT NULL DEFAULT '',
  `accessibility_bypass` smallint(5) unsigned NOT NULL DEFAULT 0,
  `accessibility_bypass_text` varchar(30) NOT NULL DEFAULT '',
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_caption` varchar(255) DEFAULT NULL,
  `table_delimiter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_header_position` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `selected_categories` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(77,'',1,1715066329,1715027581,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"bodytext\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'peterneumanndev_text','TYPO3 Functional Colors 🎨','','<p><strong>A TYPO3 demo package to showcase the functional colors system.</strong></p>',0,0,0,0,0,0,0,2,0,0,0,'orange',0,'','',NULL,NULL,0,'','',0,'1','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL),
(78,'',1,1715031954,1715031954,0,0,0,0,'',512,0,0,0,0,NULL,0,'',0,0,0,0,'peterneumanndev_image','','',NULL,0,0,0,0,1,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL),
(79,'',1,1715066393,1715062843,0,0,0,0,'',768,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"bodytext\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'peterneumanndev_text','🔒 A consistent and unbreakable system: Functional Colors','','<p><strong>\"Functional Colors\"</strong> is a <strong>dynamic</strong> and <strong>adaptable</strong> color system designed for robust web design, emphasizing flexibility and a comprehensive color palette. Key features include:</p>\r\n<ul><li><strong>CSS Custom Properties:</strong> Utilizes CSS variables to ensure consistency and easy interchangeability of color schemes in the frontend.</li><li><strong>Extensive Color Palette:</strong> Encourages a diverse range of colors rather than a limited set, allowing for greater creativity and design flexibility.</li><li><strong>Atomic Design Integration:</strong> Each small component (atom) is designed to have properties for all applicable colors, ensuring adaptability and coherence across different backgrounds.</li><li><strong>Customizable Through Background Utility Classes:</strong> Colors can be easily modified by overwriting the CSS Custom Properties within specific background utility classes, facilitating theme changes and contextual adjustments.</li></ul>\r\n\r\n',0,0,0,0,0,0,0,2,0,0,0,'gray',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL),
(80,'',1,1715066376,1715064883,0,0,0,0,'',640,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"bodytext\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'peterneumanndev_text','ℹ️ Why color management matters','','<p>Using a consistent color system with carefully chosen background colors and matching text colors is crucial in web design and programming for several reasons:</p>\r\n<ul><li><strong>Enhanced Readability and Accessibility:</strong> Proper contrast between text and background colors ensures that content is easy to read, catering to users with varying visual capabilities, including those with visual impairments.</li><li><strong>Visual Harmony:</strong> Consistent colors create a visually appealing interface, which can reduce eye strain and enhance user experience.</li><li><strong>Brand Identity:</strong> Consistent use of color strengthens brand recognition and conveys a professional image.</li><li><strong>User Navigation and Interaction:</strong> Different colors can guide users\' attention to important features and actions, improving usability and interaction.</li><li><strong>Emotional Impact:</strong> Colors have psychological effects that can influence how users feel about a website, thus impacting user engagement and retention.</li><li><strong>Cross-Device Consistency:</strong> Consistent colors ensure that a website or application maintains its appearance across different devices and platforms, providing a unified user experience.</li></ul>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL),
(81,'',1,1715065332,1715065327,0,0,0,0,'',704,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"image\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'peterneumanndev_image','','',NULL,0,0,0,0,1,0,0,2,0,0,0,'blue',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL),
(82,'',1,1715066464,1715065814,0,0,0,0,'',1024,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"bodytext\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'peterneumanndev_text','💻 Keeping developers happy','','<p>Enhancing the development process by integrating efficient tools and methodologies to streamline design and testing:</p>\r\n<ul><li><strong>Atomic Library:</strong> Features a dedicated Testing/Documentation page to develop and test all background colors and atomic components, ensuring that they perform as expected in various environments.</li><li><strong>SCSS Enhancements:</strong> Leverages SCSS capabilities, such as mixins, and nests CSS Custom property calls within SCSS variables. This approach ensures that all variables are validated during the bundling process, reducing errors and improving code reliability.</li><li><strong>Initial Investment for Long-term Gain:</strong> Emphasizes the importance of investing time in setting up systems and standards at the beginning of a project to accelerate development phases later, leading to overall efficiency and reduced time-to-release.</li></ul>\r\n<p><a href=\"t3://page?uid=16\" target=\"_blank\"><strong>Checkout the Atomic Library for this demo project!</strong></a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL),
(83,'',1,1715072591,1715066206,0,0,0,0,'',1280,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"image\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'peterneumanndev_image','','',NULL,0,0,0,0,1,0,0,2,0,0,0,'orange',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL),
(84,'',1,1715073070,1715066318,0,0,0,0,'',1536,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"bodytext\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'peterneumanndev_text','✨ Further features, concepts and ideas','','<ul><li><strong>Infinite Nesting Capability:</strong> Utilizes CSS variables to allow infinite nesting of background containers without causing specificity issues, eliminating the need for deep CSS selectors.</li><li><strong>Smart Spacing Logic:</strong> Automatically adjusts default spacing between content blocks; spacing is halved when background colors are identical to maintain visual continuity and prevent content from appearing fragmented within the same thematic area.</li></ul>\r\n<p><a href=\"t3://page?uid=47\">Checkout a demo page for the spacing logic!</a></p>\r\n<ul><li><strong>Editable Backgrounds for Advanced Users:</strong> Enables more experienced editors to modify background colors of specific content blocks independently, by preventing unexpected color mismatches.</li><li><strong>Enhanced On-scroll Animations:</strong> Supports complex scroll-triggered animations, such as transitioning between page sections and simultaneously fading background and foreground colors.</li></ul>\r\n<p><a href=\"t3://page?uid=46\">Checkout a demo of on-scroll based background animations!</a></p>',0,0,0,0,0,0,0,2,0,0,0,'gray',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL),
(85,'',46,1715073574,1715070296,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"bodytext\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'peterneumanndev_text','Orange Background','','<p><strong>Erat aptent vel parturient tempor metus penatibus viverra torquent ultrices lacinia malesuada. Mauris porttitor nullam ad habitant quam dapibus. Nisl dictumst odio nam potenti primis pharetra conubia. Ornare faucibus viverra posuere senectus imperdiet facilisi rhoncus. Adipiscing a imperdiet pharetra posuere sagittis habitasse ex.</strong></p>\r\n<p>Elementum libero ut imperdiet magna taciti class ligula si per accumsan cras. Egestas id himenaeos vel donec netus porta. Laoreet libero nisl quisque donec felis. Scelerisque consequat class quisque cras vestibulum felis potenti.</p>',0,0,0,0,0,0,0,2,0,0,0,'orange',0,'','',NULL,NULL,0,'','',0,'1','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL),
(86,'',46,1715070429,1715070316,0,0,0,0,'',512,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"bodytext\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'peterneumanndev_text','Gray Background','','<p><strong>Duis lobortis mauris consectetur sagittis cursus efficitur conubia fermentum. Sollicitudin placerat malesuada condimentum semper aenean euismod accumsan curae. Ante id facilisis imperdiet adipiscing penatibus lacus vehicula sit. Hac facilisi ligula tristique tortor suspendisse fames natoque nostra. Parturient consectetur cras scelerisque elementum class accumsan enim pretium tempor. Torquent dictumst conubia fames porta mollis lacus dignissim ad sapien mattis.</strong></p>\r\n<p>Erat nam viverra porttitor eros finibus mattis convallis. Mattis auctor phasellus per suscipit ornare maecenas facilisis. Senectus metus efficitur facilisis augue proin blandit integer in duis. Praesent aliquet enim imperdiet augue metus natoque class urna ultrices lacinia lacus. Mi ullamcorper nam penatibus quisque cubilia auctor id ut bibendum. Ad elit aliquet conubia ultricies venenatis elementum massa in lorem diam cubilia. Posuere enim viverra senectus fusce augue.</p>',0,0,0,0,0,0,0,2,0,0,0,'gray',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL),
(87,'',46,1715070436,1715070344,0,0,0,0,'',768,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"bodytext\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'peterneumanndev_text','Blue Background','','<p><strong>Suspendisse semper quis pellentesque magnis condimentum lobortis sed. Feugiat luctus nisl id ante ullamcorper venenatis arcu nostra semper. Mollis inceptos tempus porta nisl risus arcu mattis rutrum. Nostra pretium justo lorem risus potenti cras dis ex mollis. Quisque sem molestie sociosqu natoque eleifend a aptent id vulputate proin platea. Ultrices sodales enim consectetuer eros in aliquam dapibus.</strong></p>\r\n<p>Justo massa ante aliquam vitae neque cursus ornare aenean ut. Condimentum morbi cursus dis fermentum elit viverra tempus justo. Cubilia auctor vel nascetur nullam non hendrerit lobortis erat nisl habitant tellus. Quisque mollis aenean dolor hendrerit efficitur mauris taciti porttitor interdum magna. Risus commodo ultricies eget lorem letius. Risus cras imperdiet tempor dictum nisl class.</p>',0,0,0,0,0,0,0,2,0,0,0,'blue',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL),
(88,'',46,1715070387,1715070387,0,0,0,0,'',1024,0,0,0,0,NULL,0,'',0,0,0,0,'peterneumanndev_text','Default Background','','<p><strong>Fames parturient ridiculus orci taciti porttitor mus eleifend natoque ex. Conubia lacus risus si pretium pharetra curabitur. Magnis sit duis imperdiet iaculis ut. Dapibus semper accumsan consequat convallis nascetur. Amet pellentesque ornare senectus auctor habitasse consequat consectetur. Volutpat metus nullam conubia senectus pharetra elementum neque hac. Tempor eros maecenas amet fringilla letius molestie nisl elit nascetur. Ullamcorper gravida neque sociosqu magnis purus aptent adipiscing dictum.</strong></p>\r\n<p>Ex malesuada metus tincidunt eleifend fames nibh ullamcorper amet. Diam faucibus quam orci iaculis taciti curabitur neque. Senectus enim nibh cursus magnis volutpat fusce scelerisque rutrum lobortis. Id nisl dictum non vehicula lobortis. Eu interdum suscipit rhoncus quis ligula hac nisi pellentesque dictumst. Sed metus feugiat semper ultrices class dis nisl condimentum felis natoque.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL),
(89,'',46,1715070453,1715070393,0,0,0,0,'',1280,0,0,0,0,NULL,85,'{\"CType\":\"\",\"colPos\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"bodytext\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'peterneumanndev_text','Orange Background','','<p><strong>Erat aptent vel parturient tempor metus penatibus viverra torquent ultrices lacinia malesuada. Mauris porttitor nullam ad habitant quam dapibus. Nisl dictumst odio nam potenti primis pharetra conubia. Ornare faucibus viverra posuere senectus imperdiet facilisi rhoncus. Adipiscing a imperdiet pharetra posuere sagittis habitasse ex.</strong></p>\r\n<p>Elementum libero ut imperdiet magna taciti class ligula si per accumsan cras. Egestas id himenaeos vel donec netus porta. Laoreet libero nisl quisque donec felis. Scelerisque consequat class quisque cras vestibulum felis potenti.</p>',0,0,0,0,0,0,0,2,0,0,0,'orange',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,'0'),
(90,'',46,1715070457,1715070406,0,0,0,0,'',1536,0,0,0,0,NULL,87,'{\"CType\":\"\",\"colPos\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"bodytext\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'peterneumanndev_text','Blue Background','','<p><strong>Suspendisse semper quis pellentesque magnis condimentum lobortis sed. Feugiat luctus nisl id ante ullamcorper venenatis arcu nostra semper. Mollis inceptos tempus porta nisl risus arcu mattis rutrum. Nostra pretium justo lorem risus potenti cras dis ex mollis. Quisque sem molestie sociosqu natoque eleifend a aptent id vulputate proin platea. Ultrices sodales enim consectetuer eros in aliquam dapibus.</strong></p>\r\n<p>Justo massa ante aliquam vitae neque cursus ornare aenean ut. Condimentum morbi cursus dis fermentum elit viverra tempus justo. Cubilia auctor vel nascetur nullam non hendrerit lobortis erat nisl habitant tellus. Quisque mollis aenean dolor hendrerit efficitur mauris taciti porttitor interdum magna. Risus commodo ultricies eget lorem letius. Risus cras imperdiet tempor dictum nisl class.</p>',0,0,0,0,0,0,0,2,0,0,0,'blue',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,'0'),
(91,'',47,1715074130,1715073097,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"bodytext\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'peterneumanndev_text','This is the first Text-Block','','<p>Penatibus sed viverra habitant erat rhoncus justo placerat ornare integer. Fringilla imperdiet leo pellentesque pretium maximus mi quam condimentum phasellus at. Molestie penatibus dignissim in leo placerat viverra. Proin nisi scelerisque vitae auctor vulputate aenean ipsum. Pede fringilla efficitur placerat purus in cras facilisis ac convallis vitae. Iaculis scelerisque torquent habitant suscipit adipiscing. Sed aptent morbi egestas etiam ad himenaeos justo lobortis euismod. Pulvinar si taciti in at commodo habitasse lacus adipiscing.</p>\r\n<p>Tortor dictum habitant magna leo quis montes pede ridiculus dictumst mi praesent. Nunc class neque fames facilisis duis. Vulputate platea erat parturient elementum porta si condimentum. Purus diam sit rutrum quisque tempor curae est posuere fringilla dapibus nulla. Arcu tortor odio justo feugiat tristique ipsum. Mus ultricies est molestie dictum magnis placerat eleifend per proin praesent pretium. Facilisis ultrices dictumst felis consequat ipsum libero. Finibus quam pulvinar hac suspendisse dis penatibus elit.</p>',0,0,0,0,0,0,0,2,0,0,0,'orange',0,'','',NULL,NULL,0,'','',0,'1','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL),
(92,'',47,1715073531,1715073267,0,0,0,0,'',512,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"bodytext\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'peterneumanndev_text','This is follow up content in the same background color','','<p><strong>This content has less spacing than the preceding block because it has the same background color.</strong></p>',0,0,0,0,0,0,0,2,0,0,0,'orange',0,'','',NULL,NULL,0,'','',0,'3','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL),
(93,'',47,1715073616,1715073361,0,0,0,0,'',768,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"bodytext\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'peterneumanndev_text','This is a content in a new background color','','<p><strong>As a new visual content section with a new background color. This has more spacing to switch background colors.</strong></p>\r\n<p>Class maecenas pretium neque tristique eros quisque. Malesuada consequat morbi montes odio dictum tortor risus condimentum taciti faucibus. Platea orci id massa enim amet. Etiam amet commodo vehicula sagittis id urna magna. Erat neque finibus augue efficitur sem.</p>\r\n<ul><li>Donec blandit erat enim imperdiet vivamus curae tempor. Sapien tristique accumsan risus bibendum turpis lectus. Phasellus nullam commodo tempor torquent elementum diam leo erat in ligula.</li><li>Integer penatibus rutrum nulla posuere non inceptos eu adipiscing libero ut. Malesuada in cursus dis neque vulputate. Platea himenaeos fusce luctus malesuada sociosqu mollis tellus.</li><li>Vel natoque ullamcorper ut bibendum massa. Ultrices suspendisse in ac pulvinar quisque fusce.</li></ul>\r\n<p>Felis odio dapibus habitant facilisis donec id eleifend sociosqu risus. Mollis in ante fringilla posuere etiam. Eget gravida sagittis eros magna vel. Class ullamcorper scelerisque mi volutpat dictumst nec luctus fames. Sem sapien arcu ultricies praesent consectetuer.</p>\r\n\r\n',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL),
(94,'',47,1715073644,1715073644,0,0,0,0,'',1024,0,0,0,0,NULL,0,'',0,0,0,0,'peterneumanndev_image','Image on Blue','',NULL,0,0,0,0,1,0,0,2,0,0,0,'blue',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL),
(95,'',47,1715073672,1715073672,0,0,0,0,'',1280,0,0,0,0,NULL,0,'',0,0,0,0,'peterneumanndev_text','Text on same blue background','','<p>Donec mattis sapien mauris nullam finibus feugiat sem sagittis commodo dapibus senectus. Nam amet ligula dui platea ante ullamcorper velit molestie ultricies sed. Commodo volutpat duis curae nascetur consequat bibendum.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL),
(96,'',47,1715073810,1715073709,0,0,0,0,'',1536,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"bodytext\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'peterneumanndev_text','Text on Gray','','<p>Eu hendrerit rhoncus nisl nullam et ante malesuada consequat. Urna diam volutpat tempus nascetur fames.</p>',0,0,0,0,0,0,0,2,0,0,0,'gray',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL),
(97,'',47,1715073817,1715073717,0,0,0,0,'',1792,0,0,0,0,NULL,96,'{\"CType\":\"\",\"colPos\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"bodytext\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'peterneumanndev_text','Text on Default','','<p>Sapien hac fames eu facilisi suspendisse facilisis luctus pede rutrum viverra ornare. Fames pharetra eros elementum nunc urna sit vivamus netus taciti.</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,'0'),
(98,'',47,1715073827,1715073720,0,0,0,0,'',2048,0,0,0,0,NULL,96,'{\"CType\":\"\",\"colPos\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"bodytext\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'peterneumanndev_text','Text on Orange','','<p>Bibendum dapibus etiam curabitur quisque pretium sapien praesent dolor tellus mi. Fringilla ligula gravida amet massa fames pharetra.</p>',0,0,0,0,0,0,0,2,0,0,0,'orange',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,'0'),
(99,'',47,1715073835,1715073722,0,0,0,0,'',2304,0,0,0,0,NULL,96,'{\"CType\":\"\",\"colPos\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"bodytext\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'peterneumanndev_text','Text on Orange','','<p>Ad dui elementum pretium himenaeos eget maecenas mattis nullam consectetuer nunc. Aenean himenaeos gravida mattis nisi facilisis imperdiet penatibus dui nostra dolor mi.</p>',0,0,0,0,0,0,0,2,0,0,0,'orange',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,'0'),
(100,'',47,1715073854,1715073724,0,0,0,0,'',2560,0,0,0,0,NULL,96,'{\"CType\":\"\",\"colPos\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"bodytext\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'peterneumanndev_text','Text on Blue','','<p>Ad quisque hendrerit potenti himenaeos ut posuere sociosqu per fringilla. Fames nostra blandit vitae interdum et himenaeos orci pellentesque nisi elementum. Conubia turpis quisque sagittis tempus faucibus lorem aliquam pede lobortis habitant. Consectetur amet ridiculus parturient facilisi sagittis fermentum libero maximus.</p>\r\n<p>Curae augue ultricies eros rhoncus posuere. Curabitur aliquam lacinia consectetur dictumst per mattis ac facilisis curae finibus nunc. Curae lobortis ridiculus dictumst quis lacinia non pretium. Eleifend ridiculus odio magnis semper suspendisse at magna massa nibh dolor rutrum.</p>\r\n<p>Sapien semper himenaeos conubia vulputate massa sit pulvinar vestibulum nullam euismod. Diam hendrerit scelerisque ante consequat porttitor maximus penatibus. Consequat quam tincidunt mi tortor lobortis euismod ut venenatis. Ridiculus consectetuer molestie facilisi laoreet dictum porttitor facilisis proin eleifend. Tortor dis ad nulla morbi finibus curae fringilla.</p>',0,0,0,0,0,0,0,2,0,0,0,'blue',0,'','','','',0,'','',0,'0','',1,0,'',0,'','','',0,0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,'0');
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) NOT NULL DEFAULT '',
  `repository` int(11) NOT NULL DEFAULT 1,
  `remote` varchar(100) NOT NULL DEFAULT 'ter',
  `version` varchar(15) NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) NOT NULL DEFAULT '',
  `description` mediumtext DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  `last_updated` int(11) NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext DEFAULT NULL,
  `author_name` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `ownerusername` varchar(50) NOT NULL DEFAULT '',
  `md5hash` varchar(35) NOT NULL DEFAULT '',
  `update_comment` mediumtext DEFAULT NULL,
  `authorcompany` varchar(255) NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) DEFAULT NULL,
  `distribution_image` varchar(255) DEFAULT NULL,
  `distribution_welcome_image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task`
--

DROP TABLE IF EXISTS `tx_scheduler_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_scheduler_task` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `nextexecution` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_time` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_failure` text DEFAULT NULL,
  `lastexecution_context` varchar(3) NOT NULL DEFAULT '',
  `serialized_task_object` mediumblob DEFAULT NULL,
  `serialized_executions` mediumblob DEFAULT NULL,
  `task_group` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_nextexecution` (`nextexecution`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task`
--

LOCK TABLES `tx_scheduler_task` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task_group`
--

DROP TABLE IF EXISTS `tx_scheduler_task_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_scheduler_task_group` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `groupName` varchar(80) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task_group`
--

LOCK TABLES `tx_scheduler_task_group` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-07 17:27:30
